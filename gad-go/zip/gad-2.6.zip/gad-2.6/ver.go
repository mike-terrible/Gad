
// ver.go
package main

var Ver string = "2.6"
