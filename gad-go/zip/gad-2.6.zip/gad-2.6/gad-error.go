// gad-error.go
package main

import "fmt"

func GadError(s string , p *Seq, nv int) {
  fmt.Printf("!!!word: %s\n",s);
}

