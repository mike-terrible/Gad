package main

//
var ALIAS = []string { "%%%" };
var EVAL = []string { ":=", "<-", "eval", "evil", "cal", "из", "рах" };
var ARRAY = []string { "[]","array" , "ларь", "кошик" }; 
var INIT = []string { "<-","init", "так"  };
var WITH = []string { "?","with","для", "по", "ще" };
var BEGIN_COMMENT = []string { "(*","донос","исполать" };
var END_COMMENT = []string { "*)", "зри" };
var LOOP = []string { "@/","loop", "опять","далі" };
var DONE = []string { "?!)","done", "весть", "авось", "невже","погляд" };
var RETURN = []string { "result" , "exit", "ход", "дать", "здобич" };
var WHEN = []string { "|","when", "while", "когда" , "коли" };
var SIC = []string { "^^","sic","lay","here","вот", "вже" };
var ELSE = []string { "?-", "else", "иначе", "погасло", "нема", "або" };
var THEN = []string { "?+", "then","ли" ,"тогда", "так" ,"є" };
var IF = []string { "?!","if","если","горит", "чи" };
var GIVE = []string { "give", "?=","!!!", "дай", "дати" };
var JOB = []string { "@@","job", "call", "начать", "почати" };
var SHOW = []string { "!","show", "показать", "вистава" };
var MESS = []string { "!!","mess", "скрепа", "скрижаль", "грамота", "новина" };
var RUN = []string { "???","execute","exec","start","run","пора","час" };
var AMEN = []string { "amen","end","аминь","все" };
var DECLARE = []string { "dcl","declare","пусть","да", "хай" , "ну" };
//
var ON = []string { "on","зажечь", "запалити" };
var OFF = []string { "off", "потушить", "загасити" };
var STR = []string { "string","строка", "текст"  };
var NUM = []string { "integer","int","num","число","цел" };
var REAL = []string { "real","вещ", "дій" };
var LIGHT = []string { "light","свеча","свет","свічка", "світло" };
var IS = []string { "is" , "суть", "докладно", "саме"  };
var AKA = []string { ":","as","aka", "как", "пока" ,"таке", "це" }; 
var REPEAT = []string { "/@","repeat", "повтор" };
//
var PROC = []string { "proc","procedure", "десница","дело","справа" };
//



