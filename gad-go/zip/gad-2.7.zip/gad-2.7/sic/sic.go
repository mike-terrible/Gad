
package sic
// 
// sic.go
//

import (
  "strings"
  "gad/types"
  "gad/rt"
  "gad/w"
)  

func GenSic(nv int, p *types.Seq )  {
  w.To(w.GetIdent()); var i = 0; 
  for { i += 1;
    if i >= nv {
      if rt.Mode == rt.RUST { w.Wr(";"); };
      w.Wr("\n"); return;
    };
    var t = (*p)[i];
    w.Wr(t);
    if strings.HasPrefix(t,"\"") { w.Wr("\""); }; 
    w.Wr(" ");
  };
}
