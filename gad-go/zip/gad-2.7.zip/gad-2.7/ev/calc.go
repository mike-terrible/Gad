// calc.go

package ev

import (
  "fmt"
  "strings"
  "gad/words"
  "gad/cmp"
  "gad/types"
  "gad/rt"
  "gad/rc"
  "gad/w"
  "gad/asm"
  "gad/remark"
  "gad/bug"
  "gad/py"
)

var Op = " + add - sub * mul / div % mod < lt > gt <= le >= ge != ne <- -> = to == eq ";

var St []string = make([]string,255);


func Pri(op string) int {
  switch op {
  case "<","lt",">","gt","<=","le",">=","ge","!=","ne","==","eq": return 4;
  case "*","mul", "/","div","%","mod": return 3;
  case "+","add","-","sub": return 2;
  case "<-","to", "->" : return 1;
  };
  return 0;
}


func AllocResult() string {
  rc.Result = fmt.Sprintf("gad_%d",rc.Zj);
  rc.Zj += 1;
  return rc.Result;
}

func isOp(t string) bool {
  return strings.Contains(Op," " + t + " ");
}

func eoi() {
  switch rt.Mode {
  case rt.GO,rt.RUST : w.Wr(";\n");
  case rt.MOJO,rt.PYTHON: w.Wr("\n");
  }
}

func goOp1(xop string,nt int) int { 
 switch rt.Mode {
 case rt.ASM32: {
   var top = nt - 1;
   var xn1 = St[top];
   asm.Asm32AllocResult(); 
   St[top] = rc.Result;
   top += 1; 
   asm.Asm32Op1(xop,xn1); 
   return top;
 } 
 case rt.ASM: { 
   var top = nt - 1;
   var xn1 = St[top];
   asm.AsmAllocResult(); 
   St[top] = rc.Result;
   top += 1; 
   asm.AsmOp1(xop,xn1); 
   return top; 
  }};
  var top = nt - 1; 
  var xn1 = St[top];
  AllocResult();
  St[top] = rc.Result; top += 1;
  w.To(w.GetIdent()); 
  switch rt.Mode { 
  case rt.GO,rt.MOJO: w.Wr("var "); 
  case rt.RUST: w.Wr("let mut ");  
  }
  w.Wr(rc.Result, " = ", xn1, xop );
  eoi();
  return top;
}

func goAss(nt int) int {
  fmt.Printf(" goAss (%d) %s = %s\n",nt,St[nt-1],St[nt-2]);
  var /*xn2*/ xn1 = St[nt-1];
  var /*xn1*/ xn2 = St[nt-2]; 
  switch rt.Mode { 
  case rt.ASM32: { asm.Asm32Ass(xn2,xn1); return nt-2; };
  case rt.ASM: { asm.AsmAss(xn2,xn1);  return nt-2; }
  };
  w.To(w.GetIdent());
  w.Wr(xn2, " = ", xn1);
  eoi();
  return nt-2;
}

func goOp2(xop string,nt int) int {
  switch rt.Mode { 
  case rt.ASM32: {
    var top = nt;
    var /*xn2*/ xn1 = "$0";  if (nt - 1) >= 0 { /*xn2*/ xn1 = St[nt - 1]; top = nt - 1; };
    var /*xn1*/ xn2 = "$0";  if (nt - 2) >= 0 { /*xn1*/ xn2 = St[nt - 2]; top = nt - 2; };
    asm.Asm32AllocResult(); 
    St[top] = rc.Result; top += 1; 
    asm.Asm32Op2(xop,xn2,xn1); 
    return top;
  }
  case rt.ASM: {
    var top = nt;
    var /*xn2*/ xn1 = "$0";  if (nt - 1) >= 0 { /*xn2*/ xn1 = St[nt - 1]; top = nt - 1; };
    var /*xn1*/ xn2 = "$0";  if (nt - 2) >= 0 { /*xn1*/ xn2 = St[nt - 2]; top = nt - 2; };
    asm.AsmAllocResult(); 
    St[top] = rc.Result; top += 1; 
    asm.AsmOp2(xop,xn2,xn1); 
    return top; 
  }};
  var top = nt;
  var /*xn2*/ xn1 = "0";  if (nt - 1) >= 0 { /*xn2*/ xn1 = St[nt - 1]; top = nt -1; }; 
  var /*xn1*/ xn2 = "0";  if (nt - 2) >= 0 { /*xn1*/ xn2 = St[nt - 2]; top = nt -2; };
  AllocResult();
  St[top] = rc.Result; top += 1;
  w.To(w.GetIdent()); 
  switch rt.Mode { 
  case rt.GO,rt.MOJO: w.Wr("var "); case rt.RUST: w.Wr("let mut ");  
  };
  if strings.Contains(" == ; != ; > ; < ; >= ; <= ",xop) {
    rt.NeedBoolOf = true;
    w.Wr(rc.Result); w.Wr(" = ");
    if rt.Mode == rt.GO {
       w.Wr("BoolOf("); w.Wr(xn2); w.Wr(xop); w.Wr(xn1); w.Wr(")");
    };
    if (rt.Mode == rt.RUST) || (rt.Mode ==rt. PYTHON) || (rt.Mode == rt.MOJO) {
       w.Wr("bool_of("); w.Wr(xn2); w.Wr(xop); w.Wr(xn1); w.Wr(")");
    };
  } else {
    w.Wr(rc.Result); w.Wr(" = "); w.Wr(xn2); w.Wr(xop); w.Wr(xn1);
  };   
  eoi();
  return top
}

func genThen() {
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Then();
  case rt.ASM: asm.AsmThen();
  case rt.GO: GoThen();
  case rt.RUST: RustThen();
  case rt.MOJO: MojoThen();
  case rt.PYTHON: PythonThen();
  };
}

func genRepeat() {
  rc.Loops[rc.Nev - 1] = true;
  rc.Elses[rc.Nev - 1] = false;
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Repeat();
  case rt.ASM: asm.AsmRepeat();
  case rt.GO:  GoRepeat();
  case rt.RUST: RustRepeat();
  case rt.MOJO: py.MojoRepeat();
  case rt.PYTHON: py.PyRepeat();
  };
}

func InitRepeat() {
  switch rt.Mode {
  case rt.ASM32,rt.ASM: {
    w.Wr("\n");
    var zp = fmt.Sprintf("ev%d:\n",rc.Evals[ rc.Nev - 1]);
    w.Wr(zp);   
  } 
  case rt.RUST: {
    w.To(w.GetIdent());
    w.Wr("loop {");
    w.To(w.GetIdent() + 2); 
  }
  case rt.GO: {
    w.To(w.GetIdent());
    w.Wr("for {");
    w.To(w.GetIdent() + 2); 
  }
  case rt.PYTHON,rt.MOJO: {
    w.To(w.GetIdent());
    w.Wr("while True:"); 
    w.To(w.GetIdent() + 2); 
  }}
}

func FromEvil(varName string, iStart int, nv int, p *types.Seq) {
  var npp int = 0;
  var pp  types.Seq;
  var ops types.Seq;
  var cop int = 0; 
  var i int = iStart;
  for { i += 1; if i>=nv { break; }
    var t string =  (*p)[i];
    switch {
    case isOp(t): {
      var prt = Pri(t);
      for cop > 0 {
        cop -= 1;
        var py = Pri(ops[cop]);
        if py < prt { cop += 1; break; };
        pp = append(pp, ops[cop]); npp += 1; 
      };
      ops = append( ops, t ); cop ++;
    }
    case t == "(": {
      ops = append( ops, t ); cop += 1;
    }
    case t == ")": {
      for cop > 0 {
        cop -= 1
        if ops[cop] == "(" { break; };
        pp = append(pp, ops[cop]); npp++;
      };
    }
    default: {
      pp = append(pp, t); npp += 1;
    }
    };
  }; // for
  if npp>0 { 
    var za strings.Builder;
    var i = 0
    for i < npp {
      za.WriteString(" "); za.WriteString(pp[i]);
      i += 1;
    }
    remark.GenComment(za.String());
    FromCalc(varName,-1,npp,&pp); 
  }
}


/********************************************************/


func GoRepeat() {
  w.To(w.GetIdent());
  w.Wr("if "); w.Wr(rc.Result); w.Wr(" != 1 { break; }\n");
  w.To(w.GetIdent()); 
}

func RustRepeat() { 
  w.To(w.GetIdent());
  w.Wr("if "); w.Wr(rc.Result); w.Wr(" != 1 { break; }\n");
  w.To(w.GetIdent()); 
}

/********************************************************/


func GoThen() bool {
  w.To(w.GetIdent());
  w.Wr("if ");  w.Wr(rc.Result); w.Wr(" == 1 {\n");
  w.SetIdent(w.GetIdent() + 2);
  return true;
}

func RustThen() bool { return GoThen(); }

func PythonThen() bool {
  w.To(w.GetIdent());
  w.Wr("if  "); w.Wr(rc.Result); w.Wr(" == 1:\n");
  w.SetIdent(w.GetIdent() + 2); 
  return true;
}

func MojoThen() bool { return PythonThen(); }

/********************************************************/

func GoElse() {
  w.To(w.GetIdent() - 2); 
  w.Wr("} else {\n"); w.To(w.GetIdent() + 2);  
}

func GenRepeat() {
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Repeat(); 
  case rt.ASM: asm.AsmRepeat(); 
  case rt.GO: GoRepeat(); 
  case rt.RUST: RustRepeat();
  case rt.PYTHON: py.PyRepeat(); 
  case rt.MOJO: py.MojoRepeat(); 
  }
}

func RustElse() { GoElse(); }

func PythonElse() { MojoElse(); } 

func MojoElse() {
  w.To(w.GetIdent() - 2);
  w.Wr("else:\n"); w.To(w.GetIdent() + 2); 
}

/********************************************************/

func FromCalc(varName string, iStart int,nv int, p *types.Seq) int {
  bug.DbgTrace("FromCalc");
  var i = iStart;
  var top = 0;
  for { i += 1; if i >= nv { break; } 
    var t = (*p)[i]; 
    if t == "(" {  
      FromEvil(varName, i, nv, p); return 0;
    };
    var is_op = isOp(t);
    if is_op {
      switch(t) { 
      case "<-","to","->","=": top = goAss(top); 
      case "inc","++": top = goOp1(" + 1",top);
      case "<=","le":  top = goOp2(" <= ", top);
      case "<","lt":   top = goOp2(" < ",top); 
      case ">=","ge":  top = goOp2(" >= ",top);
      case ">","gt":   top = goOp2(" > ", top);
      case "!=","ne":  top = goOp2(" != ",top);
      case "==","eq":  top = goOp2(" == ", top);
      case "add","+":  top = goOp2(" + ",top);
      case "sub", "-": top = goOp2(" - ",top); 
      case "mul","*":  top = goOp2(" * ",top);
      case "div","/":  top = goOp2(" / ",top); 
      case "mod","%":  top = goOp2(" % ",top);
      };
    } else {
      St[top] = t; top += 1;
    };
  }; // for
  if varName != "?" { 
    if rt.Mode == rt.ASM32 { asm.Asm32Ass(varName,St[0]); return 0; };
    if rt.Mode == rt.ASM { asm.AsmAss(varName,St[0]); return 0;  };
    w.To(w.GetIdent());
    w.Wr(varName," = ", St[0] ); 
    eoi();
  };
  bug.DbgTrace(")FromCalc");
  return 0;
}

func GenEval(nv int, p *types.Seq) {
  bug.DbgTrace("Eval(");
  var pu types.Seq = make([]string,0) 
  var i int; var j int;
  j = 0; i = 0;
  for {
    i += 1; if i >= nv { break; }
    var cc = (*p)[i];
    if cmp.Cmp(cc , words.REPEAT ) {
      rc.EvId += 1;
      rc.Evals[rc.Nev] = rc.EvId; 
      rc.Loops[rc.Nev] = true;
      rc.Elses[rc.Nev] = false;     
      rc.Nev += 1;
      InitRepeat();
      FromCalc("?",-1, j, &pu);
      GenRepeat();
      bug.DbgTrace(")Eval");
      return;
    };
    if cmp.Cmp(cc , words.THEN ) {
      rc.EvId += 1;
      rc.Evals[rc.Nev] = rc.EvId;
      rc.Loops[rc.Nev] = false;
      rc.Elses[rc.Nev] = false;
      rc.Nev += 1;
      FromCalc("?", -1, j, &pu);
      genThen();
      bug.DbgTrace(")Eval");
      return;
    };
    pu = append(pu, cc); j += 1;
  };
  if j > 0 { FromCalc("?",-1,j,&pu); };
  bug.DbgTrace(")Eval");
}
