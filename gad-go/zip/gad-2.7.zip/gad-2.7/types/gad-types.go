
// gad-types.go

package types

const (
  UNDEF = iota 
  LIGHT = iota
  NUM = iota
  REAL = iota
  STRING = iota
)

type Seq []string

type Var struct {
  Xname string; 
  Pname string;
  IsArray bool; 
  Asize int; 
  Dtype int;
}

