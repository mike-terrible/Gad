package rt

var Mode string = GO;
var InProc = false;
var InArray = false;
var InInit int = 0;
var CurVar string = "";
var CurProc string = "modmain";

