// 
// mess.go
//
package msg

import (
  "strings"
  "gad/types"
  "gad/rt"
  "gad/w"
  "gad/asm"
)

func GenMess(nv int, p *types.Seq)  {
  w.To(w.GetIdent());
  var i = 0; i += 1; if i >= nv { return; };
  var t = (*p)[i];
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Mess(t); 
  case rt.ASM: asm.AsmMess(t); 
  case rt.RUST: {
    w.Wr("println!(");
    if strings.HasPrefix(t,"\"") { w.Wr(t, "\""); } else {  w.Wr("\"{ }\",", t ); };
    w.Wr(");\n"); 
  }
  case rt.GO: {
    w.Wr("println(", t);
    if strings.HasPrefix(t,"\"") { w.Wr("\""); };
    w.Wr(")\n");
  }
  case rt.MOJO,rt.PYTHON: {
    w.Wr("print(", t);
    if strings.HasPrefix(t, "\"") { w.Wr("\""); };
    w.Wr(")\n")
  }};
}


