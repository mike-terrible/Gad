// py_repeat.go

package py

import (
  "gad/rc"
  "gad/w"
)

func PyRepeat() { 
  w.To(w.GetIdent());
  w.Wr("if ", rc.Result, " != 1:\n");
  w.To(w.GetIdent() + 2); w.Wr("break\n");
  w.To(w.GetIdent() - 2 );
}

func MojoRepeat() {
  PyRepeat()
}


func PyLoop() { w.To(w.GetIdent()); w.Wr("pass\n"); }

func MojoLoop() { PyLoop(); } 

