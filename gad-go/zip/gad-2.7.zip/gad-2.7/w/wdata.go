package w

import (
  "bufio"
)

var Out *bufio.Writer;
var Ident int = 0;