// 
// declare.go
//
package dcl

import (
  "fmt"
  "strings"
  "gad/words"
c "gad/cmp"
  "gad/types"
  "gad/rt"
  "gad/asm"
  "gad/w"
)  

func GenDeclare(nv int, p *types.Seq)  {
  var i int = 0;
  var varV string = ""; 
  var vtype string = "";
  var val string = "";
  var vsize string = "";
  var like string = "";
  var be string = "";
  i += 1; if i < nv { varV =  (*p)[i]; };
  i += 1; 
  if i < nv { like = (*p)[i];  
    if c.Cmp(like,words.ARRAY) { 
      i += 1; if i < nv { vsize = (*p)[i]; };
      i += 1; if i < nv { vtype = (*p)[i]; }; 
      i +=1;  if i < nv { be = (*p)[i]; };
      goArray(nv,p, varV, vsize, vtype, be ); 
      return;
    };
  };
  i += 1; if i < nv { vtype = (*p)[i] };
  i += 1; if i < nv { /* be = p[i]; */};
  i += 1; if i< nv { val = (*p)[i]; };
  goVar(varV, vtype, val);
}

func GenWith(nv int, p *types.Seq) {
  var i = 0; var t = ""; var buf = ""; 
  for {
    i += 1; 
    if i >=nv { break; }
    t = (*p)[i];
    switch(rt.Mode) {
    case rt.GO, rt.RUST:
    { w.To(w.GetIdent()); w.Wr(rt.CurVar);
      buf = fmt.Sprintf("%d",rt.InInit);
      w.Wr("[", buf, "]", " = ", t);
      if strings.HasPrefix(t, "\"") { w.Wr("\""); };
      if rt.Mode == rt.RUST { w.Wr(";"); };
      w.Wr("\n");
      rt.InInit += 1;
    }  
    case rt.MOJO,rt.PYTHON:
    { w.To(w.GetIdent());
      w.Wr(rt.CurVar, ".append(", t);
      if strings.HasPrefix(t,"\"") { w.Wr("\""); };
      w.Wr(")\n");
    }};
  };
}

func goArray(nv int, p *types.Seq, varV string, vsize string, vtype string, be string) {
  if len(varV) == 0 { return; }; w.To(w.GetIdent());
  switch rt.Mode {
  case rt.GO: {
    w.Wr("var ", varV," ", "["); 
    if  vsize != "?"  { w.Wr(vsize); };
    w.Wr("]", OnType(vtype));
    if(be == "") { rt.InArray = false; w.Wr(";\n"); return; };
    rt.CurVar = varV;
    w.Wr("\n");
    rt.InArray = true; 
    if c.Cmp(be,words.AKA) {
      rt.InInit = 0;
    } else { 
      rt.InInit = 1;
      w.To(w.GetIdent());
      w.Wr(varV, "[0] = ", be);
      if strings.HasPrefix(be,"\"")  { w.Wr("\""); };
      w.Wr("\n");
    }; 
    return;
  }
  case rt.RUST: {
    if(rt.InProc)  { w.Wr("let mut ",varV); } else {  
      w.Wr("static mut ",varV);  
    };
    w.Wr(": ","[", OnType(vtype), ";");
    if  vsize != "?" { w.Wr(vsize); };
    w.Wr("]", " = [", OnValue(vtype), ";", vsize, "];\n");
    if be == "" { rt.InArray = false; return; };
    rt.CurVar = varV;
    rt.InArray = true;  
    if c.Cmp(be,words.AKA) { rt.InInit = 0; } else {
      rt.InInit = 1; w.To(w.GetIdent());
      w.Wr(varV, "[0] = ", be);
      if strings.HasPrefix(be, "\"")  { w.Wr("\""); };
      w.Wr(";");
    };
    w.Wr("\n");
    return;
  }
  case rt.PYTHON: {
    w.Wr(varV, " = [ ]\n");
    if be == "" { rt.InArray = false; w.Wr("\n"); return; };
    rt.CurVar = varV;
    rt.InArray = true; 
    if c.Cmp(be,words.AKA) { rt.InInit = 0; } else {
      rt.InInit = 1
      w.To(w.GetIdent());
      w.Wr(rt.CurVar, ".append(",  be);
      if strings.HasPrefix(be,"\"") { w.Wr("\""); };
    }; 
    w.Wr("\n");
    return;
  }
  case rt.MOJO: {
    w.Wr("var ", varV, " = List[", OnType(vtype), "]()");
    rt.CurVar = varV;
    rt.InArray = true; 
    if be == "" { rt.InArray = false; w.Wr("\n"); return; };
    if c.Cmp(be,words.AKA) { rt.InInit = 0; } else {
      rt.InInit = 1
      w.To(w.GetIdent());
      w.Wr(rt.CurVar,".append(", be ); 
      if strings.HasPrefix(be,"\"") { w.Wr("\""); };
    }; 
    w.Wr("\n");
    return;
  }};
}

func goVar(varV string, vtype string, val string )  {
  if len(varV) == 0 { return; };
  switch rt.Mode {
  case rt.ASM,rt.ASM32: { asm.AsmGoVar(varV,vtype,val);  return; }
  };
  w.To(w.GetIdent());
  switch rt.Mode {
  case  rt.GO,rt.MOJO: w.Wr("var ",varV);
  case rt.RUST: {
    if rt.InProc {
      w.Wr("let mut ", varV );
    } else { w.Wr("static mut ", varV ); }; 
  }
  case rt.PYTHON: { /* Wr(varV); */ }
  default:
  };
  if len(vtype) > 0 {
    var ztype = OnType(vtype);
    switch rt.Mode {
    case rt.GO: { w.Wr(" "); w.Wr( ztype ); }
    case rt.RUST,rt.MOJO: { w.Wr(":"); w.Wr(ztype); }
    };
  }; 
  if len(val) > 0 {
    if c.Cmp(val,words.ON) {
      switch rt.Mode {
      case rt.RUST: { w.Wr(" = true;\n"); }
      case rt.GO: { w.Wr(" = true\n"); }
      case rt.MOJO,rt.PYTHON: { w.Wr(" = True\n"); }
      };
      return ;
    };
    if c.Cmp(val,words.OFF) {
      switch rt.Mode {
      case rt.RUST: { w.Wr(" = false;\n"); }
      case rt.GO: { w.Wr(" = false\n"); }
      case rt.MOJO,rt.PYTHON: { w.Wr(" = False\n"); }
      };
      return;
    };
    w.Wr(" = ",val);
    if strings.HasPrefix(val, "\"") {  w.Wr("\""); }
    if rt.Mode == rt.RUST { w.Wr(";"); };
    w.Wr("\n");
  } else {
    switch rt.Mode {
    case rt.RUST: { w.Wr(";\n"); }
    default: { w.Wr("\n"); }
    };

  }
}   

func OnValue(vtype string) string {
  if c.Cmp(vtype,words.STR) { return "\"\"";  }
  if c.Cmp(vtype,words.NUM) { return "0";  }
  if c.Cmp(vtype,words.REAL) { return "0.0";  }
  if c.Cmp(vtype,words.LIGHT) { return "false";  };  
  return "";
}

func OnType(vtype string) string {
  switch {
  case c.Cmp(vtype,words.STR): {
    switch rt.Mode {
    case rt.GO: return "string";  case rt.RUST: return "&str";
    case rt.MOJO: return "String"; default:   return "";
    };
  }
  case c.Cmp(vtype,words.NUM): {
    switch rt.Mode {
    case rt.RUST: return "i64"; case rt.GO:  return "int"; 
    case rt.MOJO: return "Int";  default: { return ""; }
    };
  }
  case c.Cmp(vtype,words.REAL): {
    switch rt.Mode {
    case rt.RUST: return "f64"; 
    case rt.GO:  return "float64"; 
    case rt.MOJO: return "Float64";
    default: return ""; 
    };
  }
  case c.Cmp(vtype,words.LIGHT): {
    switch rt.Mode {
    case rt.GO,rt.RUST: return "bool"; 
    case rt.MOJO: return "Bool"; 
    };
  }};
  return "";
}


