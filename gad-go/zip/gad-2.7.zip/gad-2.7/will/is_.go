// 
// is_.go
//
package will

import (
  "gad/types"
  "gad/asm"
  "gad/rt"
  "gad/w"
)

func GenIs(nv int, p *types.Seq ) {
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Is(nv,p);
  case rt.ASM: asm.AsmIs(nv,p); 
  case rt.GO,rt.RUST: { w.Wr("{\n"); w.SetIdent(w.GetIdent() + 2); }
  };
}

