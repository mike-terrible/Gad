
// parse.go

package pa

import (
  "os"
  "bufio"
  "fmt"
  "strings"
  "gad/words" 
  "gad/rt"
  "gad/w"
  "gad/asm"
c "gad/cmp"
  "gad/pa/lex"
  "gad/will/errata"
  "gad/will"
  "gad/msg"
  "gad/remark"
  "gad/ev"
  "gad/dcl"
  "gad/give"
  "gad/amen"
  "gad/ru"
  "gad/proc"
  "gad/job"
  "gad/sic"
  "gad/ret"
  "gad/otherwise"
)


func Parser(fn string, mode string) {
  var dname = fn;
  if ! strings.HasSuffix(fn, ".гад") {
    dname = fmt.Sprintf("%s.гад",fn)
  }; 
  fmt.Println("input: ",dname); 
  rf,err := os.Open(dname)
  if err != nil { fmt.Println(err); return; }
  var zname = strings.ReplaceAll(dname,".гад",".out");
  rt.Mode = mode;
  switch rt.Mode {
  case rt.GO: zname = strings.ReplaceAll(zname,".out",".go"); 
  case rt.MOJO: zname = strings.ReplaceAll(zname,".out",".mojo"); 
  case rt.RUST: zname = strings.ReplaceAll(zname,".out",".rs"); 
  case rt.PYTHON: zname =strings.ReplaceAll(zname,".out",".py");
  case rt.ASM: zname =strings.ReplaceAll(zname,".out",".s"); 
  case rt.ASM32: zname =strings.ReplaceAll(zname,".out","-32.s");
  };
  fmt.Println("output: ",zname);
  fmt.Println("mode: ",rt.Mode)
  out,err := os.Create(zname)
  w.Out = bufio.NewWriter(out)
  //
  switch rt.Mode { 
  case rt.ASM,rt.ASM32: {
    w.Wr("  .text\n"); w.Wr("  .global main\n");
  }};
  if rt.Mode == rt.GO {
    w.Wr("package main\n");
    w.SetIdent(2);
  };
  //
  fs := bufio.NewScanner(rf)
  fs.Split(bufio.ScanLines)
  var a string = "";
  for fs.Scan() {
    a = fs.Text()
    fmt.Print(a,"\n")
    remark.CheckComment(a)
    if remark.IsComment { remark.GenComment(a); continue; }
    if !remark.IsLine { continue; }
    pt,nv := lex.Lexer(a)
    if nv == 0 { continue; }
    var s = pt[0];
    switch {
    case c.Cmp(s,words.LOOP): amen.GenLoop();
    case c.Cmp(s,words.DONE): amen.GenDone(); 
    case c.Cmp(s,words.RETURN): ret.GenReturn(nv,&pt);
    case c.Cmp(s,words.WHEN): ev.GenEval(nv,&pt);
    case c.Cmp(s,words.SIC): sic.GenSic(nv,&pt);  
    case c.Cmp(s,words.ELSE): otherwise.GenElse();
    case c.Cmp(s,words.IF): ev.GenEval(nv,&pt);
    case c.Cmp(s,words.GIVE): give.GenGive(nv,&pt);
    case c.Cmp(s,words.JOB): job.GenJob(nv,&pt); 
    case c.Cmp(s,words.SHOW): msg.GenShow(nv,&pt);
    case c.Cmp(s,words.MESS): msg.GenMess(nv, &pt);
    case c.Cmp(s,words.RUN): ru.GenRun(nv, &pt);
    case c.Cmp(s,words.AMEN): amen.GenAmen();
    case c.Cmp(s,words.DECLARE): dcl.GenDeclare(nv, &pt); 
    case c.Cmp(s,words.WITH): dcl.GenWith(nv , &pt);
    case c.Cmp(s,words.IS): will.GenIs(nv, &pt); 
    case c.Cmp(s,words.PROC): proc.GenProc(nv , &pt); 
    case c.Cmp(s,words.INIT): amen.GenInit(); 
    case c.Cmp(s,words.ALIAS): lex.GenAlias(nv, &pt);
    case c.Cmp(s,words.EVAL): ev.GenEval(nv,&pt);
    default: errata.GadError(s, &pt, nv); 
    };
  };
  if rt.NeedBoolOf {
    switch rt.Mode {
    case rt.RUST: {
      w.Wr("\n",
         "fn bool_of(v :bool) -> i64 {\n",
         "  if v { return 1; }\n",
         "  return 0;\n",
         "}\n");
    }
    case rt.GO: {
      w.Wr("\n",
         "  func BoolOf(v bool) int {\n",
         "    if v { return 1; }\n",
         "    return 0;\n",
         "  }\n");
    }
    case rt.PYTHON: {
      w.Wr("\n",
         "def bool_of(v) :\n",
         "  if v :\n",
         "    return 1\n",
         "  return 0\n" );
    }
    case rt.MOJO: {
      w.Wr("\n",
         "fn bool_of(v: Bool) -> Int:\n",
         "  if v:\n",
         "    return 1\n",
         "  else:\n",
         "    return 0\n",
         "pass\n");
    }};
  };
  if rt.Mode == rt.PYTHON { w.Wr("main()\n"); };
  if rt.Mode == rt.ASM32 {
    w.Wr("gad.nl: mov %esp,%ebp\n",
       "  lea gad.nlcnv,%edi\n",
       "  push %edi\n",
       "  call printf\n",
       "  mov %ebp,%esp\n",
       "  ret\n");
     //Da("gad_true:  .byte 0,0,0,0,0,0,0,1\n");
     //Da("gad_false: .byte 0,0,0,0,0,0,0,0\n");
     var z = w.Ab.String();
     w.Wr(" .data\n",
       strings.ReplaceAll(z,"\n\n","\n"), 
       "gad.nlcnv: .byte 10,0\n",
       " .section .note.GNU-stack,\"\",@progbits\n", 
       " .end\n");
     asm.VarDump();
  };
  if rt.Mode == rt.ASM {
     w.Wr("gad.nl: xor %rax,%rax\n",
       " lea gad.nlcnv(%rip),%rdi\n",
       " call puts\n",
       " ret\n");
     var z = w.Ab.String();
     w.Wr(" .data\n",
       strings.ReplaceAll(z,"\n\n","\n"), 
       "gad.nlcnv: .byte 0,0,0,0,0,0,0,0\n",
       " .section .note.GNU-stack,\"\",@progbits\n", 
       " .end\n");
     asm.VarDump();
  };
  rf.Close()
  w.Out.Flush()
  out.Close()
}

