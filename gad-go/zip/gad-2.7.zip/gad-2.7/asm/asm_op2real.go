// asm_op2real.go

package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/rc"
  "gad/w"
)  

func AsmCmpsd(cmpsdval string,xto string,xfrom string) {
  var from string; var to string;
  w.Wr("# asmCmpsd ", cmpsdval, " ", xfrom, ",", xto, "\n");
  //var literal bool = false;
  var dt = TypeOfLiteral(xfrom);
  if (dt == types.NUM) || (dt == types.REAL) {
    if dt == types.NUM { from = ValNum(xfrom); };
    if dt == types.REAL { from = ValReal(xfrom); };
    w.Wr("# movq ",xfrom,",%rax\n",
       "  movq $",from,",%rax\n",
       "  movq %rax,%xmm8\n" ); 
  } else {
    if xfrom != "gad_" { from = fmt.Sprintf("%s.%s",rt.CurProc,xfrom); 
    } else  { from = xfrom; }; 
    w.Wr("  lea "); w.Wr(from); w.Wr(",%rsi\n"); 
    w.Wr("  movq (%rsi),%xmm8\n");
  };
  dt = TypeOfLiteral(xto);
  if (dt == types.NUM) || (dt == types.REAL) {
    if dt == types.NUM { to = ValReal(xto); }
    if dt == types.REAL { to = ValReal(xto); };
    w.Wr("# movq ", xto, ",%rax\n",
       "  movq $", to, ",%rax\n",
       "  movq %rax,%xmm9\n");
  } else {
    if !strings.HasPrefix(xto,"gad_") { to = fmt.Sprintf("%s.%s",rt.CurProc,xto); 
    } else  { to = xto; }; 
    w.Wr("  lea "); w.Wr(to); w.Wr(",%rdi\n");
    w.Wr("  movq (%rdi),%xmm9\n"); 
  };
  w.Wr("  "); w.Wr(cmpsdval); w.Wr(" %xmm8,%xmm9\n");
  w.Wr("  lea "); w.Wr(rc.Result); w.Wr("(%rip),%rsi\n");
  w.Wr("  movq %xmm9,%rbx\n");
  w.Wr("  andq $1,%rbx\n");
  w.Wr("  movq %rbx,(%rsi)\n");
}

func AsmOp2Real(opcode string, xto string,xfrom string) {
  var from string; var to string;
  w.Wr("# asmOp2Real ", opcode, " ", xfrom, ",", xto, "\n");
  var dt = TypeOfLiteral(xfrom);
  switch dt {
  case types.NUM, types.REAL: {
     var dl string;
     if dt == types.NUM  { dl = ValNum(xfrom); }
     if dt == types.REAL { dl = ValReal(xfrom); }
     from = fmt.Sprintf("$%s",dl);
     w.Wr("# movq ", xfrom, ",%rax\n", "  movq ", from, ",%rax\n",
        "  movq %rax,%xmm8\n"); 
  } 
  default: {
    if !strings.HasPrefix(xfrom, "gad_") { from = fmt.Sprintf("%s.%s",rt.CurProc,xfrom); 
    } else  { from = xfrom; }; 
    w.Wr("  lea ", from, ",%rsi\n",
       "  movq (%rsi),%xmm8\n");
  }};
  dt = TypeOfLiteral(xto);
  switch dt  { 
  case types.NUM, types.REAL: {
    var dl string;
    if dt == types.NUM  { dl = ValNum(xto); }
    if dt == types.REAL { dl = ValReal(xto); }
    to = fmt.Sprintf("$%s",dl); 
    w.Wr("# movq ",xto,",%rax\n",
       "  movq ", to,",%rax\n",
       "  movq %rax,%xmm9\n");
  } 
  default: {
    if !strings.HasPrefix(xto,"gad_") { to = fmt.Sprintf("%s.%s",rt.CurProc,xto);
    } else  { to = xto; }; 
    w.Wr("  lea ",to,",%rdi\n",
       "  movq (%rdi),%xmm9\n");         
  }};
  w.Wr("  ",opcode," %xmm8,%xmm9\n",
     "  lea ",rc.Result,"(%rip),%rsi\n",
     "  movq %xmm9,(%rsi)\n");
}



