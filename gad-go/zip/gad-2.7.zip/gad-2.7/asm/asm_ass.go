
// asm_ass.go

package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/w"
)


func AsmAss(xto string ,xfrom string) {
  w.Wr("# asmAss ", xfrom,",", xto, "\n");
  var from string; var to string;
  var dt = TypeOfLiteral(xfrom);
  switch(dt) {
  case types.REAL: {
    from = ValReal(xfrom);
    w.Wr("# movq ", xfrom, ",%rsi\n",
       "  movq $", from, ",%rsi\n");
  }
  case types.NUM: {
    from = ValNum(xfrom);
    w.Wr("# movq ", xfrom, ",%rsi\n",
       "  movq $", from, ",%rsi\n"); 
  }
  case types.UNDEF: {
    if ! strings.HasPrefix(xfrom,"gad_") { from = fmt.Sprintf("%s.%s",rt.CurProc,xfrom);
    } else { from = xfrom; };
    w.Wr("  lea ", from, "(%rip),%rsi\n",
       "  movq (%rsi),%rsi\n");
  }
  };
  if ! strings.HasPrefix(xto,"gad_") {  to = fmt.Sprintf("%s.%s",rt.CurProc,xto);
  } else { to = xto; };
  w.Wr("  lea ", to, "(%rip),%rdi\n",
     "  movq %rsi,(%rdi)\n");
}

