// calc.go

package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/rc"
  "gad/w"
)  

func asmOp1(xop string) {
  if xop == " + 1" {
    w.Wr("  inc %rbx\n"); 
  };
}


func AsmOp1(xop string,xn string) {
  if strings.Contains("0123456789",xn[0:0]) {
    var buf = "$" + xn;
    w.Wr("  movq ",buf,",%rbx\n"); 
  } else {
     w.Wr("  lea ");
     if !strings.HasPrefix(xn,"gad_") { w.Wr(rt.CurProc,"."); };
     w.Wr(xn,",%rdi\n",
        "  movq (%rdi),%rbx\n");
  };
  asmOp1(xop);
  w.Wr("  mov %rbx,(%rdi)\n");
}

func AsmSetBit(setv string) {
  w.Wr("  xor %rax,%rax\n");
  w.Wr("  cmp %rsi,%rdi\n");
  w.Wr(setv);
  w.Wr("  mov %rax,%rdi\n");
}

func AsmOp2(xop string, xto string, xfrom string) {
  //
  var dt = AsmTypeOf(xfrom); var dtx = AsmTypeOf(xto);
  if (dt == types.REAL)||(dtx == types.REAL) {
     switch xop {
     case " + ":  { AsmOp2Real("addsd ",xto,xfrom); }
     case " - ": { AsmOp2Real("subsd ",xto,xfrom); }
     case " * ": { AsmOp2Real("mulsd ",xto,xfrom); }
     case " / ": { AsmOp2Real("divsd ",xto,xfrom); }
     /****************************************************************/
     case " == ": { AsmCmpsd(/* cmpsd $0,*/ "cmpeqsd ", xto, xfrom); }
     case " < ": { AsmCmpsd(/* cmpsd $1, */ "cmpltsd ", xto, xfrom); }
     case " <= ": { AsmCmpsd(/* cmpsd $2,*/ "cmplesd ", xto, xfrom); }
     case " != ": { AsmCmpsd(/* cmpsd $4,*/ "cmpneqsd ", xto, xfrom); }
     case " >= ": { AsmCmpsd(/* cmpsd $5,*/ "cmpnltsd " , xto, xfrom); }
     case " > ": { AsmCmpsd( /* cmpsd $6,*/ "cmpnlesd " , xto, xfrom); }
     };
     return;
  };
  w.Wr("# asmOp2 ",xop," ", xfrom, ",", xto, "\n");
  var from = ""; var to = "";
  dt = TypeOfLiteral(xfrom);
  if dt == types.NUM {
    from = fmt.Sprintf("$%s",xfrom);
    w.Wr("  movq ", from, ",%rsi\n"); 
  } else {
    if !strings.HasPrefix(xfrom,"gad_") { from = fmt.Sprintf("%s.%s",rt.CurProc,xfrom); 
    } else { from = xfrom; }
    w.Wr("  lea ", from, ",%rsi\n","  movq (%rsi),%rsi\n");
  };
  //
  dt = TypeOfLiteral(xto);
  if(dt == types.NUM) {
    to = fmt.Sprintf("$%s",xto);
    w.Wr("  movq ", to, ",%rdi\n"); 
  } else {
    if !strings.HasPrefix(xto,"gad_") { to = fmt.Sprintf("%s.%s",rt.CurProc,xto); 
    } else { to = xto; };
    w.Wr("  lea ", to, ",%rdi\n", "  movq (%rdi),%rdi\n");
  };
  //
  switch xop {
  case " + ": w.Wr("  add %rsi,%rdi\n"); 
  case " - ": w.Wr("  sub %rsi,%rdi\n"); 
  case " * ": w.Wr("  imul %rsi,%rdi\n"); 
  case " / ": w.Wr("  idiv %rsi,%rdi\n"); 
  case " == ": AsmSetBit("  sete %al\n");
  case " < ": AsmSetBit("  setb %al\n");
  case " <= ": AsmSetBit("  setbe %al\n");
  case " > ": AsmSetBit("  seta %al\n");
  case " >= ": AsmSetBit("  setae %al\n"); 
  case " != ": AsmSetBit("  setne %al\n"); 
  };
  //
  w.Wr("  lea ", rc.Result, "(%rip),%rsi\n", "  movq %rdi,(%rsi)\n");
}

