// is_pole.go

package ev

import (
  "gad/types"
)

func NotPole (iStart int, nv int, p *types.Seq) string {
  var q = "";
  var i = iStart;
  for i < nv {
    var t,_ = types.I(i,nv,p);
    if IsOp(t) {
      q = q + "p";
    } else { q = q + "t"; };
    if q == "tpt" { break; }
    if q == "tt" { break; }
    i += 1
  };
  return q;
}

func Braces(iStart int, nv int, p *types.Seq) ( pn *types.Seq, np int ) {
  var pp types.Seq = make(types.Seq,0);
  pp = append(pp,"("); var kk = 1;
  var i = iStart;
  for i < nv {
    var q,e = types.I(i,nv,p); if e { break; };
    pp = append( pp, q )
    kk += 1;
    i += 1;
  };
  pp = append( pp, ")"); kk += 1;
  pn = &pp;
  np = kk;
  return;
}

