// eval.go
package ev

import (
  "gad/rc"
  "gad/types"
  "gad/words"
  "gad/bug"
  "gad/cmp"
)


func GenEval(nv int, p *types.Seq) {
  bug.DbgTrace("Eval(");
  var pu types.Seq = make([]string,0) 
  var i int; var j int;
  j = 0; i = 0;
  for {
    i += 1; if i >= nv { break; }
    var cc,_ = types.I(i,nv,p);
    if cmp.Cmp(cc , words.REPEAT ) {
      rc.EvId += 1;
      rc.Evals[rc.Nev] = rc.EvId; 
      rc.Loops[rc.Nev] = true;
      rc.Elses[rc.Nev] = false;     
      rc.Nev += 1;
      InitRepeat();
      FromCalc("?",-1, j, &pu);
      GenRepeat();
      bug.DbgTrace(")Eval");
      return;
    };
    if cmp.Cmp(cc , words.THEN ) {
      rc.EvId += 1;
      rc.Evals[rc.Nev] = rc.EvId;
      rc.Loops[rc.Nev] = false;
      rc.Elses[rc.Nev] = false;
      rc.Nev += 1;
      FromCalc("?", -1, j, &pu);
      genThen();
      bug.DbgTrace(")Eval");
      return;
    };
    pu = append(pu, cc); j += 1;
  };
  if j > 0 { FromCalc("?",-1,j,&pu); };
  bug.DbgTrace(")Eval");
}
