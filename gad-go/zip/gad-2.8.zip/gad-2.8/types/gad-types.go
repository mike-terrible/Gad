
// gad-types.go

package types

const (
  UNDEF = iota 
  LIGHT = iota
  NUM = iota
  REAL = iota
  STRING = iota
)

type Seq []string

type Var struct {
  Xname string; 
  Pname string;
  IsArray bool; 
  Asize int; 
  Dtype int;
}

func I(i int, nv int, s *Seq) ( v string, e bool ) { 
  if i < 0 { v = ""; e = true; return; };
  if i >= nv  { v = ""; e = true; return; };
  e = false; v = (*s)[i];
  return;
}

