// 
// show.go
//
package msg

import (
  "strings"
  "gad/words"
  "gad/types"
  "gad/rt"
  "gad/w"
  "gad/imp/asm"
c "gad/cmp"
)

func GenShow(nv int, p *types.Seq )  {
  var i = 0; 
  for { i += 1; if i >= nv { break; }; var t = (*p)[i];
    if c.Cmp(t,words.WITH) { 
       i += 1; if i >= nv { break; }; 
       t = (*p)[i]; 
       switch rt.Mode {
       case rt.ASM32: asm.Asm32Show(t);
       case rt.ASM: asm.AsmShow(t);
       case rt.RUST: {
         w.To(w.GetIdent()); w.Wr("print!(\"{ } \",", t); 
         if strings.HasPrefix(t, "\"") {  w.Wr("\"");  };  
         w.Wr(");\n");
       }
       case rt.GO: {
         w.To(w.GetIdent()); w.Wr("print(", t ); 
         if strings.HasPrefix(t,"\"") { w.Wr("\""); };
         w.Wr(",\" \");\n");
       }
       case rt.MOJO, rt.PYTHON: {
         w.To(w.GetIdent()); w.Wr("print(", t); 
         if strings.HasPrefix(t,"\"") { w.Wr("\""); }; 
         w.Wr(",end =\" \")\n");
       }}; // match
    }; // if
  }; // loop
}


