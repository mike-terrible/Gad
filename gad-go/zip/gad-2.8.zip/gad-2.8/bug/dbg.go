
// dbg.go
//
package bug

import (
  "gad/rt"
  "gad/w"
)

var Dbg = false

func OnDebugNoNL(s string) {
  if !Dbg { return; }
  w.To(w.GetIdent());
  switch rt.Mode {
  case rt.RUST,rt.GO: w.Wr("//!! "); 
  default: w.Wr("#!! ");
  };
  w.Wr(s);
}

func OnDebug(s string) {
  if !Dbg { return; }
  OnDebugNoNL(s);
  w.Wr("\n");
}


func DbgTrace(s string) {
  if !Dbg { return; };
  w.To(w.GetIdent());
  switch rt.Mode {
  case rt.RUST,rt.GO: w.Wr("//!! " + s);
  default: w.Wr("#!! " +  s);
  };
}


