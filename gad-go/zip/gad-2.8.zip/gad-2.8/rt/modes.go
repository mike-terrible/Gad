package rt
  const GO = "-go";
  const RUST = "-rust";
  const MOJO = "-mojo";
  const PYTHON = "-python";
  const ASM = "-asm";
  const ASM32 = "-asm32";
  var NeedBoolOf = false;
