package rc

var EvId = 0;
var Nev = 0;

var Evals []int = make([]int,255);
var Thens []bool = make([]bool,255);
var Loops []bool = make([]bool,255); 
var Elses []bool = make([]bool,255);

