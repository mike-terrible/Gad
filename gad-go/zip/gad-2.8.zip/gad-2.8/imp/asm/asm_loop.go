package asm

import (
  "fmt"
  "gad/rc"
  "gad/w"
)

func Asm32Loop() bool{ return AsmLoop(); }

func AsmLoop() bool {
  var z = fmt.Sprintf("%d",rc.Evals[rc.Nev-1]);
  w.Wr("\n","# loop ev",z,"\n");
  w.Wr("  jmp ev"); w.Wr(z); w.Wr("\n"); 
  w.Wr("leave_"); w.Wr(z); w.Wr(": nop\n");
  rc.Nev -= 1;
  return true;
}
