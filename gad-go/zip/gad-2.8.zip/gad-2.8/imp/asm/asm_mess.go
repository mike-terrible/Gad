//
// asm_mess.go
//
package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/w"
)

var NeedNL bool = false;

func AsmShow(t string) {
  w.Wr("\n","# asmShow ",t); 
  if strings.HasPrefix(t,"\"") { w.Wr("\""); }
  w.Wr("\n");
  var b = ""; var bval = "";
  var lt = 0;
  var dt = TypeOfLiteral(t);
  switch dt {
  case types.STRING: {
    lt = GetLit();
    b = fmt.Sprintf("gad_c%d", lt);
    w.Da(b); w.Da(": "); w.Da("  .asciz "); w.Da(t); w.Da("\"\n");
    w.Da(b); w.Da(".cnv: "); w.Da(" .asciz \"%s\"\n");
    w.Wr("  lea ", b, "(%rip),%rsi\n",
       "  lea ", b, ".cnv(%rip),%rdi\n",
       "  sub %rax,%rax\n",
       "  call printf\n");
    return;
  }
  case types.NUM: {
    lt = GetLit();
    b = fmt.Sprintf("gad_cnv%d",lt); 
    w.Da(b); w.Da(":\n");
    w.Da("  .asciz \""); w.Da("%ld"); 
    w.Da("\"\n");
    w.Wr("  lea ", b, "(%rip),$rdi\n",
       "  movq $", t, ",%rsi\n",
       "  sub %rax,%rax\n",
       "  call printf\n");
    return;
  }  
  case types.REAL: {
    lt = GetLit();
    b = fmt.Sprintf("gad_cnv%d",lt); 
    w.Da(b);  w.Da(":\n");
    w.Da("  .asciz \"%lg\"\n");
    var dd = ValReal(t);
    bval = fmt.Sprintf("$%ld",dd);
    w.Wr("  movq ",bval,",%rax\n",
       "  movq %rax,%xmm0\n",
       "  movq $1,%rax\n",
       "  lea ", b, "(%rip),%si\n",
       "  call printf\n");
    return;
  }};
  if strings.HasPrefix(t,"gad_") { return; }
  var v *types.Var = VarGet(t); if v == nil { return; }
  dt = (*v).Dtype;
  switch dt {
  case types.STRING: 
    w.Wr("  xor %rax,%rax\n",
       "  lea ", rt.CurProc, ".",  t,  "(%rip),%rsi\n",
       "  lea ", rt.CurProc, ".", t,  ".cnv(%rip),%rdi\n",
       "  call printf\n",
       "# end of asmShow\n" );
  case types.NUM: 
    w.Wr("  lea ", rt.CurProc, ".",  t, "(%rip),%rsi\n",
       "  lea ", rt.CurProc, ".",  t, ".cnv(%rip),%rdi\n",
       "  movq (%rsi),%rsi\n",
       "  xor %rax,%rax\n",
       "  call printf\n",
       "# end of asmShow\n");
  case types.REAL: {
    w.Wr("  movq $1,%rax\n",
       "  lea ",rt.CurProc, ".", t, ",%rdi\n",
       "  movq (%rdi),%xmm0\n",
       "  lea ", rt.CurProc,".", t, ".cnv(%rip),%rdi\n",
       "  call printf\n" ,
       "# end of asmShow\n");
  }};
}

func AsmMess(t string) {
  NeedNL = true;
  w.Wr("\n","# asmMess ",t); 
  if strings.HasPrefix(t,"\"") { w.Wr("\""); }
  w.Wr("\n");
  var b = ""; var bval = "";
  var lt = 0;
  var dt = TypeOfLiteral(t);
  switch dt {
  case types.STRING: {
    lt = GetLit();
    b = fmt.Sprintf("gad_c%d", lt);
    w.Da(b); w.Da(":\n");
    w.Da("  .asciz "); w.Da(t); w.Da("\"\n");
    w.Wr("  lea ", b, "(%rip),%rdi\n",
       "  sub %rax,%rax\n",
       "  call puts\n");
    return;
  }
  case types.NUM: {
    lt = GetLit();
    b = fmt.Sprintf("gad_cnv%d",lt); 
    w.Da(b); w.Da(":\n");
    w.Da("  .asciz \""); w.Da("%ld"); 
    w.Da("\"\n");
    w.Wr("  lea ", b, "(%rip),$rdi\n",
       "  movq $", t, ",%rsi\n",
       "  sub %rax,%rax\n",
       "  call printf\n",
       "  call gad.nl\n");
    return;
  }  
  case types.REAL: {
    lt = GetLit();
    b = fmt.Sprintf("gad_cnv%d",lt); 
    w.Da(b);  w.Da(":\n");
    w.Da("  .asciz \"%lg\"\n");
    var dd = ValReal(t);
    bval = fmt.Sprintf("$%ld",dd);
    w.Wr("  movq ",bval,",%rax\n",
       "  movq %rax,%xmm0\n",
       "  movq $1,%rax\n",
       "  lea ", b, "(%rip),%si\n",
       "  call printf\n",
       "  call gad.nl\n");
    return;
  }};
  if strings.HasPrefix(t,"gad_") { return; }
  var v *types.Var = VarGet(t); if v == nil { return; }
  dt = (*v).Dtype;
  switch dt {
  case types.STRING: {
    w.Wr("  xor %rax,%rax\n",
       "  lea ", rt.CurProc, ".",  t,  "(%rip),%rsi\n",
       "  lea ", rt.CurProc, ".", t,  ".cnv(%rip),%rdi\n",
       "  call printf\n",
       "  call gad.nl\n",
       "# end of asmMess\n" )
  }
  case types.NUM: {
    w.Wr("  lea ", rt.CurProc, ".",  t, "(%rip),%rsi\n",
       "  lea ", rt.CurProc, ".",  t, ".cnv(%rip),%rdi\n",
       "  movq (%rsi),%rsi\n",
       "  xor %rax,%rax\n",
       "  call printf\n",
       "  call gad.nl\n",
       "# end of asmMess\n")
  }
  case types.REAL: {
    w.Wr("  movq $1,%rax\n",
       "  lea ",rt.CurProc, ".", t, ",%rdi\n",
       "  movq (%rdi),%xmm0\n",
       "  lea ", rt.CurProc,".", t, ".cnv(%rip),%rdi\n",
       "  call printf\n" ,
       "  call gad.nl\n" ,
       "# end of asmMess\n")
  }};
}



