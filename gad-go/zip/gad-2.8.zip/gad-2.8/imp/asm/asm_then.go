// asm_then.go
package asm

import (
  "fmt"
  "gad/rc"
  "gad/w"
)

func Asm32Then() {
  var cur = rc.Nev - 1
  w.Wr("  movl ", rc.Result, ",%eax\n");
  //Wr("  and $1,%eax\n");
  w.Wr("  neg %eax\n");
  w.Wr("  jnc "); w.Wr(" else"); w.Wr( fmt.Sprintf("%d",rc.Evals[cur]) ); w.Wr("\n");
  rc.Thens[cur] = true;
  rc.Elses[cur] = false;
}

func AsmThen() {
  var cur = rc.Nev - 1
  w.Wr("  movq "); w.Wr(rc.Result); w.Wr("(%rip),%rax\n");
  //Wr("  and $1,%eax\n");
  w.Wr("  neg %rax\n");
  w.Wr("  jnc "); w.Wr(" else"); w.Wr( fmt.Sprintf("%d",rc.Evals[cur]) ); w.Wr("\n");
  rc.Thens[cur] = true;
  rc.Elses[cur] = false;
}
