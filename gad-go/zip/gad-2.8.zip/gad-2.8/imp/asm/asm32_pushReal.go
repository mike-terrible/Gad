//
// asm32_pushReal.s
//
package asm

import (
  "gad/w"
)

func Asm32pushReal(result string) {
  w.Wr("  lea ",result,",%esi\n",
       "  movl (%esi),%eax\n",
       "  add $4,%esi\n",
       "  movl (%esi),%ebx\n",
       "  push %ebx\n",
       "  push %eax\n");
}