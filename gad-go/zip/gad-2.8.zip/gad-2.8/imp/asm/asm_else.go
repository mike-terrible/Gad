package asm

import (
  "fmt"
  "gad/rc"
  "gad/w"
)

func Asm32Else() bool { return AsmElse(); }

func AsmElse()  bool { 
  var cur = rc.Nev - 1
  var lb = rc.Evals[cur];
  rc.Elses[cur] = true;
  var z = fmt.Sprintf("%d",lb);
  w.Wr("\n  jmp done"); w.Wr(z); w.Wr("\n"); 
  w.Wr("else"); w.Wr(z); w.Wr(": nop\n");
  return true;
}
