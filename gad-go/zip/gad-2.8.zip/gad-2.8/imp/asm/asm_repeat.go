// asm_repeat.go
package asm

import (
  "fmt"
  "gad/rc"
  "gad/w"
)

func Asm32Repeat() {
  w.Wr("# Asm32Repeat\n");
  w.Wr("  cmpl $1,"); w.Wr(rc.Result); w.Wr("\n");
  w.Wr("  jnz "); w.Wr(fmt.Sprintf("leave_%d\n",rc.Evals[rc.Nev - 1])); w.Wr("\n");
}

func AsmRepeat() {
  w.Wr("# AsmRepeat\n");
  w.Wr("  lea "); w.Wr(rc.Result); w.Wr(",%rsi\n");
  w.Wr("  mov (%rsi),%rax\n");
  w.Wr("  dec %rax\n");
  w.Wr("  jnz "); w.Wr(fmt.Sprintf("leave_%d\n",rc.Evals[rc.Nev - 1])); w.Wr("\n");
}
