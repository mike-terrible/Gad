//asm32_op2real.go
package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/rc"
  "gad/w"
)  

func asm32fcom(cc string,qfrom string,qto string) {
  w.Wr("# asm32fcom ",cc," ",qfrom,",",qto," result: ",rc.Result,"\n");
  w.Wr("  ffree %st(0)\n");
  w.Wr("  ffree %st(1)\n");
  w.Wr("  xor %edx,%edx\n");
  w.Wr("  fldl ",qfrom,"\n",
       "  fldl ",qto,"\n");
  w.Wr("  fcom\n");
  w.Wr("  fstsw %ax\n");
  w.Wr("  sahf\n");
  w.Wr("  ffree %st(0)\n");
  w.Wr("  ffree %st(1)\n");
  //var lb,lbe = Fcom();
  switch cc {
  case " < ":  w.Wr("  setb %dl\n");
  case " <= ": w.Wr("  setbe %dl\n");
  case " > ":  w.Wr("  seta %dl\n");
  case " >= ": w.Wr("  setae %dl\n");
  case " == ": w.Wr("  sete %dl\n");
  case " != ": w.Wr("  setne %dl\n");
  default: {
     w.Wr("# ill op ",cc,"\n"); 
     return; 
  }};
  w.Wr("  movb %dl,",rc.Result,"\n");
  w.Wr("  movl %edx,",rc.Result,"\n");
}


func asm32op2real(cc string,from string,to string) {
  w.Wr("# asm32op2real ",cc," ",from,",",to," result: ",rc.Result,"\n");
  w.Wr("  ffree %st(0)\n");
  w.Wr("  ffree %st(1)\n");
  w.Wr("  fldl ",from,"\n",
       "  fldl ",to,"\n");
  w.Wr("  ",cc," %st(1),%st(0)\n");
  w.Wr("  fstl ",rc.Result,"\n");
  w.Wr("  ffree %st(0)\n");
  w.Wr("  ffree %st(1)\n");
}

func Asm32real2(xop string,xto string,xfrom string) {
  var from = ""; var to = "";
  var dt = TypeOfLiteral(xfrom);
  switch dt { 
  case types.REAL,types.NUM: {
    var lt = GetLit(); 
    from = Lit(lt);
    w.Da(from); w.Da(":\n");
    w.Da("  .double "); w.Da(xfrom); w.Da("\n");
  }
  default: {
    if strings.HasPrefix(xfrom,"gad_") {
      from = xfrom; 
    } else { 
      from = fmt.Sprintf("%s.%s",rt.CurProc,xfrom);
    };
  }};
  //
  dt = TypeOfLiteral(xto);
  if (dt == types.NUM) || (dt == types.REAL ) {
    var lt = GetLit(); to = Lit(lt);
    w.Da(to); w.Da(":\n");
    w.Da("  .double "); w.Da(xto); w.Da("\n");
  } else {
    if !strings.HasPrefix(xto,"gad_") { to = fmt.Sprintf("%s.%s",rt.CurProc,xto); 
    } else { to = xto; };
  };

  //
  switch xop {
  case " = "," != ", " < ", " <= ", " > ", " >= ": asm32fcom(xop,from,to);
  case " + ": asm32op2real("fadd",from,to);
  case " - ": asm32op2real("fsub",from,to);
  case " * ": asm32op2real("fmul",from,to);
  case " / ": asm32op2real("fdiv",from,to);
  default: w.Wr("# unsupported operation ",xop,"\n");
  };
}

