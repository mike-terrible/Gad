package asm

import "gad/types"

func Asm32GenJob(nv int, p *types.Seq ) {

}

func AsmGenJob(nv int, p *types.Seq ) {

}
