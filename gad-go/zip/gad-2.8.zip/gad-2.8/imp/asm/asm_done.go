package asm

import (
  "fmt"
  "gad/rc"
  "gad/w"
)

func Asm32Done() bool { return AsmDone(); }

func AsmDone() bool {
   var cur = rc.Nev - 1;
   w.Wr("\n");
   if !rc.Elses[cur]  {
      w.Wr("else"); w.Wr(fmt.Sprintf("%d",rc.Evals[rc.Nev - 1]) ); w.Wr(": nop\n");
   };
   w.Wr("done"); w.Wr(fmt.Sprintf("%d",rc.Evals[rc.Nev -1]) ); w.Wr(": nop\n"); 
   rc.Nev -= 1;
  return true;
}
