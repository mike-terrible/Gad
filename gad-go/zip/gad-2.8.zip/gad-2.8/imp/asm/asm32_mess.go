//
// asm32_mess.go
//
package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/w"
)


func Asm32Show(t string) {
  w.Wr("\n","# asm32Show ",t); 
  if strings.HasPrefix(t,"\"") { w.Wr("\""); }
  w.Wr("\n");
  var b = ""; 
  var lt = 0;
  var dt = TypeOfLiteral(t);
  switch dt {
  case types.STRING: {
    lt = GetLit();
    b = Lit(lt);
    w.Da(b); w.Da(": "); w.Da("  .asciz "); w.Da(t); w.Da("\"\n");
    w.Da(b); w.Da(".cnv: "); w.Da(" .asciz \"%s\"\n");
    w.Wr("  lea ", b, ",%esi\n",
         "  lea ", b, ".cnv,%edi\n",
         "  sub %eax,%eax\n",
         "  mov %esp,%ebp\n",
         "  pushl %esi\n",
         "  pushl %edi\n",
         "  call printf\n",
         "  mov %ebp,%esp\n");
    return;
  }
  case types.NUM: {
    lt = GetLit();
    b = Lit(lt); 
    w.Da(b); w.Da(".cnv:\n"); w.Da("  .asciz \""); w.Da("%ld"); w.Da("\"\n");
    w.Wr("  lea ", b, ",%edi\n",
       "  mov; $", t, ",%esi\n",
       "  sub %eax,%eax\n",
       "  mov %esp,%ebp\n",
       "  pushl %esi\n",
       "  pushl %edi\n",
       "  call printf\n",
       "  mov %ebp,%esp");
    return;
  }  
  case types.REAL: {
    lt = GetLit();
    var b1 = Lit(lt);
    var b1f = fmt.Sprintf("%g\n",t);
    w.Da(b1); w.Da(": .double "); w.Da(b1f); 
    w.Da(b1); w.Da(".cnv:\n"); w.Da("  .asciz \"%lg\"\n");
    w.Wr("  mov %esp,%ebp\n");
    Asm32pushReal(b1);
    w.Wr("  lea ", b1, ".cnv,%edi\n");
    w.Wr("  push %edi\n");
    w.Wr("  call printf\n");
    w.Wr("  mov %ebp,%esp\n");
    return;
  }};
  if strings.HasPrefix(t,"gad_") { return; }
  var v *types.Var = VarGet(t); if v == nil { return; }
  dt = (*v).Dtype;
  switch dt {
  case types.STRING: 
    w.Wr("  xor %eax,%eax\n",
       "  lea ", rt.CurProc, ".",  t,  ",%esi\n",
       "  lea ", rt.CurProc, ".", t,  ".cnv,%edi\n",
       "  mov %esp,%ebp\n",
       "  pushl %esi\n",
       "  pushl %edi\n",
       "  call printf\n",
       "  mov %ebp,%esp\n",
       "# end of asm32Show\n" );
  case types.NUM: 
    w.Wr("  lea ", rt.CurProc, ".",  t, ",%esi\n",
       "  lea ", rt.CurProc, ".",  t, ".cnv,%edi\n",
       "  movl (%esi),%esi\n",
       "  mov %esp,%ebp\n",
       "  pushl %esi\n",
       "  pushl %edi\n",
       "  call printf\n",
       "  mov %ebp,%esp\n",
       "# end of asm32Show\n");
  case types.REAL: {
    var memo = fmt.Sprintf("%s.%s",rt.CurProc,t);
    w.Wr("  lea ",memo , ",%esi\n",
       "  lea ", memo, ".cnv,%edi\n",
       "  mov %esp,%ebp\n");
    Asm32pushReal(rt.CurProc + "." + t);
    w.Wr("  pushl %edi\n",
       "  call printf\n" ,
       "  mov %ebp,%esp\n",
       "# end of asmShow\n");
    } 
  };
}

func Asm32Mess(t string) {
  w.Wr("\n","# asm32Mess ",t); 
  if strings.HasPrefix(t,"\"") { w.Wr("\""); }
  Asm32Show(t);
  w.Wr("\n"," call gad.nl\n");
}


