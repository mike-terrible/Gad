// imp_mojo.go

package mojo

import (
  "gad/rc"
  "gad/w"
)

func MojoThen() bool {
  w.To(w.GetIdent());
  w.Wr("if  "); w.Wr(rc.Result); w.Wr(" == 1:\n");
  w.SetIdent(w.GetIdent() + 2); 
  return true;
}

func MojoElse() {
  w.To(w.GetIdent() - 2);
  w.Wr("else:\n"); w.To(w.GetIdent() + 2); 
}


func MojoRepeat() {
  w.To(w.GetIdent());
  w.Wr("if ", rc.Result, " != 1:\n");
  w.To(w.GetIdent() + 2); w.Wr("break\n");
  w.To(w.GetIdent() - 2 );
}

func MojoLoop() { w.To(w.GetIdent()); w.Wr("pass\n"); }

