// imp_rust.go

package ru

import (
  "gad/rc"
  "gad/w"
g  "gad/imp/go"
)

func RustLoop() { g.GoLoop(); }

func RustElse() { g.GoElse(); }

func RustThen() bool { return g.GoThen(); }

func RustRepeat() { 
  w.To(w.GetIdent());
  w.Wr("if "); w.Wr(rc.Result); w.Wr(" != 1 { break; }\n");
  w.To(w.GetIdent()); 
}
