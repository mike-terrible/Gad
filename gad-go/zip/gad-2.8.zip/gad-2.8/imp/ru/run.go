// 
// run.go
//
package ru

import (
  "gad/types"
  "gad/rt"
  "gad/w"
)

func GenRun(nv int, p *types.Seq )  {
  var i = 0; 
  rt.InProc = true;
  i += 1; if i >= nv { return; };
  var xmain = (*p)[i]; 
  i += 1; if i >= nv { return; };
  w.To(w.GetIdent());
  switch rt.Mode {
  case rt.RUST: w.Wr("fn main() {\n"); 
  case rt.GO:   w.Wr("func main() {"); 
  case rt.MOJO: w.Wr("fn main() :\n"); 
  case rt.PYTHON: w.Wr("def main() :\n"); 
  case rt.ASM32: {
    w.Wr("main: push %eax\n",
       xmain,": xor %eax,%eax\n");
    rt.CurProc = xmain;
    return;
  }
  case rt.ASM: {
    w.Wr("main: push %rax\n",
       xmain,": xor %rax,%rax\n");
    rt.CurProc = xmain;
    return;
  }};
  switch rt.Mode { 
  case rt.RUST: { 
    w.To(w.GetIdent() + 2);
    w.Wr("unsafe { ", xmain, "();  };\n");
    w.To(w.GetIdent() - 2); w.Wr("}\n");
    w.To( w.GetIdent() );
    w.Wr("unsafe fn ", xmain, "() {\n");
    w.To(w.GetIdent() + 2);
  }
  case rt.GO: {
    w.To(w.GetIdent() + 2); w.Wr(xmain, "()");
    w.To(w.GetIdent() - 2); w.Wr("}\n");
    w.To(w.GetIdent()); w.Wr("func ", xmain, "() {\n");
    w.To(w.GetIdent() + 2);
  }
  case rt.MOJO: {
    w.To(w.GetIdent() + 2); w.Wr(xmain,"()\n");
    w.To(w.GetIdent() - 2); w.Wr("}\n");
    w.To(w.GetIdent()); w.Wr("fn ", xmain, "() :\n");
    w.To(w.GetIdent() + 2 );
  }
  case rt.PYTHON: {
    w.To(w.GetIdent() + 2); w.Wr(xmain, "()\n");
    w.To(w.GetIdent() - 2); 
    w.Wr("def ", xmain, "() :\n");
    w.To(w.GetIdent() + 2);
  }};
}


