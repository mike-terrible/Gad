// 
// job.rs
//
package job

import (
  "strings"
  "gad/words"
  "gad/imp/asm"
  "gad/types"
  "gad/rt"
  "gad/w"
c "gad/cmp"
)  


func GenJob(nv int, p *types.Seq ) {
  if rt.Mode == rt.ASM32 { asm.Asm32GenJob(nv, p ); return; }
  if rt.Mode == rt.ASM { asm.AsmGenJob(nv, p ); return; }
  var i = 0;
  i += 1; if i >= nv { return; };
  var t = (*p)[i];
  w.To(w.GetIdent()); w.Wr(t, "(");
  var np = 0; 
  for { i += 1; if i >= nv { break; }; t = (*p)[i];
    if c.Cmp(t,words.WITH) { i += 1; if i >= nv { break; }; 
      t = (*p)[i]; np += 1; if np > 1 { w.Wr(","); };
      w.Wr(t);
      if strings.HasPrefix(t,"\"") { w.Wr("\""); };
    }; 
  };
  if rt.Mode == rt.RUST { w.Wr(");\n"); } else { w.Wr(")\n"); };
}


