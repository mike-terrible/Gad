
//comments.go

package remark

import (
  "gad/words"
  "gad/rt"
  "gad/cmp"
  "gad/w"
)

var IsComment bool = false;
var IsLine = true;

func CheckComment(a string) { 
  switch {
  case cmp.Cmp(a, words.END_COMMENT ): {
    IsComment = false; IsLine = false;
  }
  case cmp.Cmp(a, words.BEGIN_COMMENT): {
    IsComment = true;  IsLine = false;
  }
  default: { IsLine = true; }
  };
}

func GenComment(a string) {
 if !IsLine { return; };
 if (rt.Mode == rt.ASM) || (rt.Mode == rt.ASM32) { w.Wr("\n","# ", a, "\n"); return; };
 w.To(w.GetIdent());
 switch rt.Mode {
 case rt.RUST,rt.GO : w.Wr("// ", a ,  "\n" ); 
 case rt.MOJO,rt.PYTHON :  w.Wr("# ", a, "\n"); 
 };
}

