// gad-error.go
package errata

import (
  "fmt"
  "gad/types"
)

func GadError(s string , p *types.Seq, nv int) {
  fmt.Printf("!!!word: %s\n",s);
}

