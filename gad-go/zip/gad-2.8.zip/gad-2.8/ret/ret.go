package ret

import (
  "strings"
  "gad/types"
  "gad/w"
  "gad/rt"
)  

func GenReturn( nv int,p *types.Seq ) {
  var i = 0; 
  //
  i += 1;
  if i == nv { w.To(w.GetIdent()); w.Wr("return");
    if rt.Mode == rt.RUST { w.Wr(";"); };
    w.Wr("\n");
    return;
  };
  var t = (*p)[i]; w.To(w.GetIdent()); 
  w.Wr("return ",t); 
  if strings.HasPrefix(t,"\"") {
    w.Wr("\"");
    if rt.Mode == rt.RUST { w.Wr(".to_string()"); };
  };  
  if rt.Mode == rt.RUST { w.Wr(";"); };
  w.Wr("\n"); 
} 


