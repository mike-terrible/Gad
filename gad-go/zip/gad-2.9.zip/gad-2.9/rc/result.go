package rc

var Zj int = 0
var Result string = "";
