// 
// proc.go
//
package proc

import (
  "gad/words"
  "gad/types"
  "gad/rt"
  "gad/w"
c "gad/cmp"
  "gad/dcl"
)

func GenProc(nv int, p *types.Seq ) {
  var narg = 0;
  rt.InProc = true;
  var i = 0;
  w.To(w.GetIdent());
  switch rt.Mode {
  case rt.GO: w.Wr("func ");
  case rt.PYTHON: w.Wr("def ");
  case rt.MOJO:   w.Wr("fn ");
  case rt.RUST:   w.Wr("unsafe fn "); 
  };
  i += 1; if i>= nv { return; }; var xn = (*p)[i];
  w.Wr(xn, "(");
  for { i += 1; if i >= nv { w.Wr(") "); break; };
    var it_is,_ = types.I(i,nv,p);
    switch {
    case c.Cmp(it_is, words.RETURN): {
      i += 1; if i>= nv { break; }; var act,_ = types.I(i,nv,p);
      var ztype = dcl.OnType(act);
      if rt.Mode == rt.PYTHON { w.Wr(") :\n"); w.SetIdent(w.GetIdent() + 2); return; };
      var nz = len(ztype);
      if nz > 0 {
         switch rt.Mode {
         case rt.GO: {
            w.Wr(") ", ztype, " {\n"); w.SetIdent( w.GetIdent() + 2); return;
         }
         case rt.MOJO: {
           w.Wr(") -> ", ztype, " :\n"); 
           w.SetIdent( w.GetIdent() + 2 ); return;
         }
         case rt.RUST:  {
           w.Wr(") -> ");
           if ztype == "&str" { w.Wr("String"); } else { w.Wr(ztype ); };
           w.Wr(" {\n");
           w.SetIdent( w.GetIdent() + 2 ); 
           return; 
         }};  
      }; // nz > 0
    } // RETURN
    case c.Cmp(it_is, words.IS): {
      switch rt.Mode {
      case rt.RUST , rt.GO: { w.Wr(") {\n"); } 
      case rt.MOJO , rt.PYTHON: { w.Wr(") :\n"); }
      };
      w.SetIdent(w.GetIdent() + 2 );
      return;
    }
    case c.Cmp(it_is, words.WITH): {
      i += 1; if i >= nv { return; }; var varV,_ = types.I(i,nv,p); narg += 1;
      i += 1; if i >= nv { return; }; 
      if narg >1 { w.Wr(","); };
      w.Wr(varV);
      var like,_ = types.I(i,nv,p);
      if c.Cmp(like, words.AKA) {
        i += 1; if i >= nv { return; }; 
        var xtype,_ = types.I(i,nv,p);
        var ztype = dcl.OnType(xtype);
        switch rt.Mode {
        case rt.GO: w.Wr(" ", ztype ); 
        case rt.MOJO,rt.RUST: w.Wr(" :", ztype); 
        };
      };  // AKA    
    }}  // WITH
  }; // loop
}

