package rt
  const GO int8 = 1;   // "-go";
  const RUST int8 = 2; // "-rust";
  const MOJO int8 = 3; // "-mojo";
  const PYTHON int8 = 4; // "-python";
  const ASM int8 = 5; // "-asm";
  const ASM32 int8 = 6; // "-asm32";
  var NeedBoolOf = false;

  func SetMode(qm string) {
    switch qm {
    case "-go": { Mode = GO; }
    case "-rust": { Mode = RUST; }
    case "-mojo": { Mode = MOJO; }
    case "-python": { Mode = PYTHON; }
    case "-asm": { Mode = ASM; }
    case "-asm32": { Mode = ASM32; }
    default: { Mode = GO; }
    };
   }

   func GetMode() string {
      switch Mode {
      case GO: { return "-go"; }
      case RUST: { return "-rust"; }
      case MOJO: { return "-mojo"; }
      case PYTHON: { return "-python"; }
      case ASM: { return "-asm"; }
      case ASM32: { return "-asm32"; }
      default: { return "unset"; }
      };
    }