package rt

var Mode int8 = GO;
var InProc = false;
var InArray = false;
var InInit int = 0;
var CurVar string = "";
var CurProc string = "modmain";

