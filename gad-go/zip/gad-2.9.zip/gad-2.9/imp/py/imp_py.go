// imp_py.go

package py

import (
  "gad/imp/mojo"
)

func PythonThen() bool { return mojo.MojoThen(); }
func PythonElse() { mojo.MojoElse(); }

func PyRepeat() { mojo.MojoRepeat(); }

func PyLoop() { mojo.MojoLoop(); } 
