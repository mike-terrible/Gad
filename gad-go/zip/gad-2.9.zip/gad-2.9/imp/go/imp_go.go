package ev

import (
  "gad/rc"
  "gad/w"
)

func GoLoop() {
  w.To(w.GetIdent()); w.Wr("}\n");
}


func GoRepeat() {
  w.To(w.GetIdent());
  w.Wr("if "); w.Wr(rc.Result); w.Wr(" != 1 { break; }\n");
  w.To(w.GetIdent()); 
}

func GoThen() bool {
  w.To(w.GetIdent());
  w.Wr("if ");  w.Wr(rc.Result); w.Wr(" == 1 {\n");
  w.SetIdent(w.GetIdent() + 2);
  return true;
}

func GoElse() {
  w.To(w.GetIdent() - 2); 
  w.Wr("} else {\n"); w.To(w.GetIdent() + 2);  
}
