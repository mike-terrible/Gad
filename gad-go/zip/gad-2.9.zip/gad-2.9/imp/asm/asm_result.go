package asm

import ( 
  "fmt"
  "gad/rc"
  "gad/w"
)

func Asm32AllocResult() {
  rc.Result = fmt.Sprintf("gad_%d",rc.Zj);
  w.Da(rc.Result); w.Da(":\n"); w.Da("  .long 0,0\n");
  rc.Zj += 1;
}

func AsmAllocResult() {
  rc.Result = fmt.Sprintf("gad_%d",rc.Zj);
  w.Da(rc.Result); w.Da(":\n"); w.Da("  .quad 0\n");
  rc.Zj += 1;
}
