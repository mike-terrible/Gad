// asm_govar.go

package asm

//import "unsafe"

import (
  "fmt"
  "strings"
  "strconv"
  "math"
  "gad/words"
  "gad/types"
  "gad/rt"
  "gad/w"
c "gad/cmp"
)

var NVar int = 0
var Vars []types.Var = make([]types.Var,0)

func ValReal(a string) string {
  var d float64;
  d,_  = strconv.ParseFloat(a,64);
  var u = math.Float64bits(d);
  return strconv.FormatUint(u,10);
}

func ValNum(a string) string {
  var d uint64;
  d,_ = strconv.ParseUint(a,10,64);
  return strconv.FormatUint(d,10);
}

func TypeOfLiteral(t string) int {
  if strings.HasPrefix(t,"\"") { return types.STRING; }
  if strings.Contains("0123456789",t[0:1]) {
    if strings.Contains(t,"e") { return types.REAL; }
    if strings.Contains(t,"E") { return types.REAL; }
    if strings.Contains(t,".") { return types.REAL; }
    return types.NUM;
  };
  return types.UNDEF;
}

func AsmTypeOf(t string) int {
  var v *types.Var = VarGet(t); 
  if(v != nil) { return (*v).Dtype; }
  return TypeOfLiteral(t);
}


func VarGet(xn string) *types.Var {
  var i = NVar; 
  for i > 0 {
    i -= 1;
    if Vars[i].Xname == xn { return &(Vars[i]); }
  };
  return nil;
}


func VarNew(xn string, isA bool,asize int, xtype int) *types.Var {
  var nvar types.Var;
  var i int = NVar; 
  NVar += 1;
  Vars = append( Vars, nvar )
  Vars[i].Xname = xn;
  Vars[i].IsArray = isA;
  Vars[i].Asize = asize;
  Vars[i].Dtype = xtype;
  return &(Vars[i]);
}

func VarDump() {
  fmt.Print("\n xref: \n");
  var i = 0;
  for i < NVar {
    fmt.Printf("%s.",Vars[i].Pname);
    fmt.Printf("%s :",Vars[i].Xname);
    var dt = Vars[i].Dtype;
    switch(dt) {
    case types.UNDEF:  fmt.Printf(" %s\n","Undef");
    case types.LIGHT:  fmt.Printf(" %s\n","Light");
    case types.NUM:    fmt.Printf(" %s\n","Num"); 
    case types.REAL:   fmt.Printf(" %s\n","Real");
    case types.STRING: fmt.Printf(" %s\n","String");
    };
    i += 1;
  };
  fmt.Printf("\n");
}

func GenAsmFmt(fmt string,varV string) {
  w.Da("\n"); w.Da(rt.CurProc); w.Da("."); w.Da(varV); w.Da(".cnv:\n");
  w.Da("  .asciz \""); w.Da(fmt); w.Da("\"\n");
}

func AsmGoVar(varV string,vtype string,val string ) {
  var dt = types.UNDEF; w.Da(rt.CurProc); w.Da("."); w.Da(varV); w.Da(":\n"); 
  if len(val) > 0 {
    if c.Cmp(vtype,words.STR) {  
       w.Da("  .asciz "); w.Da(val); w.Da("\""); GenAsmFmt("%s",varV); dt = types.STRING; 
    };
    if c.Cmp(vtype,words.NUM) { w.Da("  .quad "); w.Da(val); 
      GenAsmFmt("%d",varV); dt = types.NUM;  
    };
    if c.Cmp(vtype,words.REAL) { w.Da("  .double "); w.Da(val); 
      GenAsmFmt("%g",varV); dt = types.REAL;  
    };
    if c.Cmp(vtype,words.LIGHT) {  w.Da(" .quad ");
      var one = "1";
      if c.Cmp(val,words.ON) { one = "1"; }
      if c.Cmp(val,words.OFF) { one = "0"; }
      w.Da(one);
      GenAsmFmt("%d",varV); dt = types.LIGHT;      
    };
    VarNew(varV,false,0,dt); 
    return;
  };
  switch {  
  case c.Cmp(vtype,words.STR): { w.Da("  .space 256,0\n"); 
    GenAsmFmt("%s",varV); dt = types.STRING; 
  }  
  case c.Cmp(vtype,words.NUM): { w.Da("  .quad 0\n"); 
    GenAsmFmt("%d",varV); dt = types.NUM; 
  }  
  case c.Cmp(vtype,words.REAL): { w.Da("  .double 0.0\n"); GenAsmFmt("%g",varV); 
    dt = types.REAL; 
  }
  case c.Cmp(vtype,words.LIGHT): { w.Da("  .quad 0\n"); GenAsmFmt("%d",varV); 
    dt = types.LIGHT; 
  }};
  VarNew(varV,false,0,dt);
}

