// asm_is.go

package asm 

import "gad/types"

func Asm32Is(nv int, p *types.Seq ) { }
func AsmIs(nv int, p *types.Seq ) { }
