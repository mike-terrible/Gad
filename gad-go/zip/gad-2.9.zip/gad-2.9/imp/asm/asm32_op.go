
// asm32_op.go

package asm

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/rc"
  "gad/w"
)  

var MathOp bool = false;

func asm32Op1(xop string) {
  if xop == " + 1" { w.Wr("  inc %ebx\n");  };
}

func Asm32Op1(xop string,xn string) {

}


func Asm32SetBit(setv string) {
  w.Wr("# Asm32SetBit ",setv,"\n");
  w.Wr("  xor %eax,%eax\n");
  w.Wr("  movl (%esi),%ebx\n");
  w.Wr("  movl (%edi),%ecx\n");
  w.Wr("  cmp %ebx,%ecx\n");
  w.Wr(setv);
  w.Wr("  movl %eax,",rc.Result,"\n");
}


func Asm32cmd2(cc string,from string,to string) {
  MathOp = true;
  w.Wr("# Asm32cmd2 ",cc," ",from,",",to,",result: ",rc.Result,"\n");
  w.Wr("  movl ",from,",%ebx\n");
  w.Wr("  movl ",to,",%ecx\n");
  w.Wr("  ", cc," %ebx,%ecx\n"); 
  w.Wr("  movl %ecx,",rc.Result,"\n");
}
 
func Asm32Op2(xop string, xto string, xfrom string) {
  var dt = AsmTypeOf(xfrom); var dtx = AsmTypeOf(xto);
  if ( dt == types.REAL ) || ( dtx == types.REAL ) {
    Asm32real2(xop,xto,xfrom);
    return;
  };
  w.Wr("# asm32Op2 ",xop," ", xfrom, ",", xto, "\n");
  var from = ""; var to = "";
  dt = TypeOfLiteral(xfrom);
  switch dt { 
  case types.NUM: {
    var lt = GetLit(); 
    from = Lit(lt);
    w.Da(from); w.Da(":\n");
    w.Da("  .long "); w.Da(xfrom); w.Da("\n");
    w.Da("  .long 0\n");
    w.Wr("# dtype == DTYPE_NUM,from = ",from,"\n");
    w.Wr("  lea ",from,",%esi\n");
  }
  default: {
    if strings.HasPrefix(xfrom,"gad_") {
      from = xfrom; 
      w.Wr("# gad internal from = ",from,"\n");
      w.Wr("  lea ",from,",%esi\n");
    } else { 
      from = fmt.Sprintf("%s.%s",rt.CurProc,xfrom);
      w.Wr("# from = ",from,"\n");
      w.Wr("  lea ",from,",%esi\n");  
    };
  }};
  //
  dt = TypeOfLiteral(xto);
  if(dt ==types.NUM) {
    var lt = GetLit(); var to = Lit(lt);
    w.Da(to); w.Da(":\n");
    w.Da("  .long "); w.Da(xto); w.Da("\n");
    w.Da("  .long 0\n");
    w.Wr("  lea ", to, ",%edi\n"); 
  } else {
    if !strings.HasPrefix(xto,"gad_") { to = fmt.Sprintf("%s.%s",rt.CurProc,xto); 
    } else { to = xto; };
    w.Wr("  lea ", to, ",%edi\n");
  };
  //
  MathOp = false;
  //
  switch xop {
  case " + ": Asm32cmd2("addl",from,to);
  case " - ": Asm32cmd2("subl",from,to); 
  case " * ": Asm32cmd2("imul",from,to); 
  case " / ": Asm32cmd2("idivl",from,to); 
  case " == ": Asm32SetBit("  sete %al\n");
  case " < ":  Asm32SetBit("  setb %al\n");
  case " <= ": Asm32SetBit("  setbe %al\n");
  case " > ":  Asm32SetBit("  seta %al\n");
  case " >= ": Asm32SetBit("  setae %al\n"); 
  case " != ": Asm32SetBit("  setne %al\n"); 
  };
  //
}


