package asm

import ( 
  "gad/rt"
  "gad/w"
)

func Asm32Amen() {
  rt.InProc = false;
  w.Wr("# amen ",rt.CurProc,"\n");
  w.Wr("  pop %eax\n","  ret\n");
}

func AsmAmen() {
  rt.InProc = false;
  w.Wr("# amen ",rt.CurProc,"\n");
  w.Wr("  pop %rax\n","  ret\n");
}