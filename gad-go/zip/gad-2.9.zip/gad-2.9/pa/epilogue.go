// epilogue.go

package pa

import (
  "strings"
  "gad/rt"
  "gad/w"
  "gad/imp/asm"
)

func genBoolOf() {
  switch rt.Mode {
  case rt.RUST: {
    w.Wr("\n",
         "fn bool_of(v :bool) -> i64 {\n",
         "  if v { return 1; }\n",
         "  return 0;\n",
         "}\n");
  }
  case rt.GO: {
    w.Wr("\n",
         "  func BoolOf(v bool) int {\n",
         "    if v { return 1; }\n",
         "    return 0;\n",
         "  }\n");
  }
  case rt.PYTHON: {
    w.Wr("\n",
         "def bool_of(v) :\n",
         "  if v :\n",
         "    return 1\n",
         "  return 0\n" );
  }
  case rt.MOJO: {
    w.Wr("\n",
         "fn bool_of(v: Bool) -> Int:\n",
         "  if v:\n",
         "    return 1\n",
         "  else:\n",
         "    return 0\n",
         "pass\n");
  }};  
}

func Epilogue () {
  if rt.NeedBoolOf { genBoolOf(); };
  switch rt.Mode {
  case rt.ASM32: {
    w.Wr("gad.nl: mov %esp,%ebp\n",
       "  lea gad.nlcnv,%edi\n",
       "  push %edi\n",
       "  call printf\n",
       "  mov %ebp,%esp\n",
       "  ret\n");
      var z = w.Ab.String();
     w.Wr(" .data\n",
       strings.ReplaceAll(z,"\n\n","\n"), 
       "gad.nlcnv: .byte 10,0\n",
       " .section .note.GNU-stack,\"\",@progbits\n", 
       " .end\n");
     asm.VarDump();
  }
  case rt.ASM : {
     w.Wr("gad.nl: xor %rax,%rax\n",
       " lea gad.nlcnv(%rip),%rdi\n",
       " call puts\n",
       " ret\n");
     var z = w.Ab.String();
     w.Wr(" .data\n",
       strings.ReplaceAll(z,"\n\n","\n"), 
       "gad.nlcnv: .byte 0,0,0,0,0,0,0,0\n",
       " .section .note.GNU-stack,\"\",@progbits\n", 
       " .end\n");
     asm.VarDump();
  }};
}
