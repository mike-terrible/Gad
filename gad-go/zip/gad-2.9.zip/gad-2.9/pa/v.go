package pa

import (
  "gad/words"
  "gad/types" 
c "gad/cmp"
  "gad/pa/lex"
  "gad/will"
  "gad/msg"
  "gad/ev"
  "gad/dcl"
  "gad/give"
  "gad/amen"
   "gad/imp/ru"
   "gad/proc"
   "gad/job"
   "gad/sic"
   "gad/ret"
   "gad/otherwise"
)


func VLoop(s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.LOOP) {  amen.GenLoop(); return true; };
  return false;
}

func VDone(s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.DONE) {  amen.GenDone(); return true; };
  return false;
}

func VRet(s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.RETURN) {  ret.GenReturn(nv,p); return true; };
  return false;
}

func VWhen(s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.WHEN) {  ev.GenEval(nv,p); return true; };
  return false;
}

func VSic(s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.SIC) { sic.GenSic(nv,p); return true; };
  return false;
}

func VElse (s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.SIC) { otherwise.GenElse(); return true; };
  return false;
}

func VIf (s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.IF) { ev.GenEval(nv,p); return true; };
  return false;
}

func VGive (s string, nv int , p *types.Seq ) bool {
  if c.Cmp(s,words.GIVE) { give.GenGive(nv,p); return true; };
  return false;
}

func VJob (s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.JOB) { job.GenJob(nv,p); return true; };
  return false; 
}

func VShow(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.SHOW) { msg.GenShow(nv,p); return true; };
  return false;
}

func VMess(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.MESS) { msg.GenMess(nv,p); return true; };
  return false;
}

func VRun(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.RUN) { ru.GenRun(nv,p); return true; };
  return false;
}

func VAmen(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.AMEN) { amen.GenAmen();  return true; };
  return false;
}

func VDeclare(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.DECLARE) { dcl.GenDeclare(nv, p);  return true; };
  return false;
}

func VWith(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.DECLARE) { dcl.GenWith(nv, p);  return true; };
  return false;
}

func VIs(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.IS) { will.GenIs(nv, p); return true; };
  return false;
}


func VProc(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.PROC) { proc.GenProc(nv, p); return true; };
  return false;
}

func VInit(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.PROC) { amen.GenInit(); return true; };
  return false;
}

func VAlias(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.ALIAS) { lex.GenAlias(nv, p);   return true; };
  return false;
}

func VEval(s string, nv int, p *types.Seq ) bool {
  if c.Cmp(s,words.EVAL) { ev.GenEval(nv, p);   return true; };
  return false;
}
