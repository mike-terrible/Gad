
// parse.go

package pa

import (
  "os"
  "bufio"
  "fmt"
  "strings"
  "gad/types" 
  "gad/rt"
  "gad/w"
  "gad/remark"
  "gad/pa/lex"
    "gad/ev"

)

type Par struct { f func (string,int,*types.Seq ) bool; }


var be = [20]Par {  Par { f: VLoop, }, Par { f: VDone, }, Par { f: VRet, }, 
  Par{ f: VWhen, }, Par { f: VSic, }, Par { f: VElse, }, 
  Par { f: VIf, }, Par { f: VGive, }, Par { f: VJob, }, 
  Par { f: VShow, }, Par { f :VMess, }, Par { f: VRun, },
  Par { f: VAmen, }, Par { f :VDeclare, }, Par { f :VWith, },
  Par { f: VIs, }, Par { f :VProc, }, Par { f :VInit, },
  Par { f :VAlias, }, Par { f :VEval, },
};

func It(s string, nv int, p *types.Seq) bool {
  var i = 0;
  var n = len(be);
  for i < n {
    var g = be[i]; i += 1;
    if g.f(s,nv,p) { return true; };
  };
  return false;
}

func Parser(fn string, mode string) {
  var dname = fn;
  if ! strings.HasSuffix(fn, ".гад") {
    dname = fmt.Sprintf("%s.гад",fn)
  }; 
  fmt.Println("input: ",dname); 
  rf,err := os.Open(dname)
  if err != nil { fmt.Println(err); return; }
  var zname = strings.ReplaceAll(dname,".гад",".out");
  rt.SetMode(mode);
  switch rt.Mode {
  case rt.GO: zname = strings.ReplaceAll(zname,".out",".go"); 
  case rt.MOJO: zname = strings.ReplaceAll(zname,".out",".mojo"); 
  case rt.RUST: zname = strings.ReplaceAll(zname,".out",".rs"); 
  case rt.PYTHON: zname =strings.ReplaceAll(zname,".out",".py");
  case rt.ASM: zname =strings.ReplaceAll(zname,".out",".s"); 
  case rt.ASM32: zname =strings.ReplaceAll(zname,".out","-32.s");
  }; 
  fmt.Println("output: ",zname);
  fmt.Println("mode: ",rt.GetMode())
  out,err := os.Create(zname)
  w.Out = bufio.NewWriter(out)
  //
  switch rt.Mode { 
  case rt.ASM,rt.ASM32: {
    w.Wr("  .text\n"); w.Wr("  .global main\n");
  }};
  if rt.Mode == rt.GO {
    w.Wr("package main\n");
    w.SetIdent(2);
  };
  //
  fs := bufio.NewScanner(rf)
  fs.Split(bufio.ScanLines)
  var a string = "";
  for fs.Scan() {
    a = fs.Text()
    fmt.Print(a,"\n")
    remark.CheckComment(a)
    if remark.IsComment { remark.GenComment(a); continue; }
    if !remark.IsLine { continue; }
    pt,nv := lex.Lexer(a); if nv == 0 { continue; };
    var s = pt[0]; if It(s,nv,&pt) { continue; };
    ev.GenDefault(nv,&pt);
  };
  Epilogue();
  rf.Close()
  w.Out.Flush()
  out.Close()
}

