
// alias.go
//
package lex

import "gad/types"

var Alias = make(map[string]string);

func GenAlias( nv int, p *types.Seq ) {
  var i = 0;
  i += 1; var k,ke = types.I(i,nv,p); if ke { return; };
  i += 1; var v,ve = types.I(i,nv,p); if ve { return; };
  Alias[k] = v;
}


