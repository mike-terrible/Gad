// eval.go
package ev

import (
  "fmt"
  "gad/rc"
  "gad/types"
  "gad/words"
  "gad/bug"
  "gad/cmp"
)

func GenDefault( nv int, p *types.Seq ) { 
  fmt.Println("GenDefault { }",nv);
  var pt types.Seq = make(types.Seq,0);
  pt = append(pt,"eval");
  var i = 0;
  for {
    var t,b = types.I(i,nv,p); if b { break; };
    i += 1;
    pt = append(pt,t);
  };
  Eval(len(pt),&pt); 
}

func GenEval( nv int, p *types.Seq) { 
  fmt.Println("GenEval { }",nv);
  Eval(nv,p); 
}

func Eval(nv int, p *types.Seq) {
  bug.DbgTrace("Eval(");
  var pu types.Seq = make([]string,0) 
  var i = 0; var j int = 0; var before = -1;
  for {
    i += 1; var cc,fuck = types.I(i,nv,p);
    if fuck { break; };
    if cmp.Cmp(cc , words.REPEAT ) {
      rc.EvId += 1;
      rc.Evals[rc.Nev] = rc.EvId; 
      rc.Loops[rc.Nev] = true;
      rc.Elses[rc.Nev] = false;     
      rc.Nev += 1;
      InitRepeat();
      FromCalc("?", before , j, &pu);
      GenRepeat();
      bug.DbgTrace(")Eval");
      return;
    };
    if cmp.Cmp(cc , words.THEN ) {
      rc.EvId += 1;
      rc.Evals[rc.Nev] = rc.EvId;
      rc.Loops[rc.Nev] = false;
      rc.Elses[rc.Nev] = false;
      rc.Nev += 1;
      FromCalc("?", before , j, &pu);
      genThen();
      bug.DbgTrace(")Eval");
      return;
    };
    pu = append(pu, cc); j += 1;
  };
  if j > 0 { FromCalc("?", before ,j,&pu); };
  bug.DbgTrace(")Eval");
}
