// is_op.go
package ev

import (
  "strings"
)

const Op = " + add - sub * mul / div % mod < lt > gt <= le >= ge != ne <- -> = to == eq ";

func IsOp(t string) bool {
  return strings.Contains(Op," " + t + " ");
}

func Pri(op string) int {
  switch op {
  case "<","lt",">","gt","<=","le",">=","ge","!=","ne","==","eq": return 4;
  case "*","mul", "/","div","%","mod": return 3;
  case "+","add","-","sub": return 2;
  case "<-","to", "->" : return 1;
  };
  return 0;
}
