// evil.go
package ev

import (
  "strings"
  "gad/types"
  "gad/remark"
)

func FromEvil(varName string, iStart int, nv int, p *types.Seq) {
  var npp int = 0;
  var pp  types.Seq;
  var ops types.Seq;
  var cop int = 0; 
  var i int = iStart;
  for { i += 1; if i>=nv { break; }
    var t string =  (*p)[i];
    switch {
    case IsOp(t): {
      var prt = Pri(t);
      for cop > 0 {
        cop -= 1;
        var py = Pri(ops[cop]);
        if py < prt { cop += 1; break; };
        pp = append(pp, ops[cop]); npp += 1; 
      };
      ops = append( ops, t ); cop ++;
    }
    case t == "(": {
      ops = append( ops, t ); cop += 1;
    }
    case t == ")": {
      for cop > 0 {
        cop -= 1
        if ops[cop] == "(" { break; };
        pp = append(pp, ops[cop]); npp++;
      };
    }
    default: {
      pp = append(pp, t); npp += 1;
    }
    };
  }; // for
  if npp>0 { 
    var za strings.Builder;
    var i = 0
    for i < npp {
      za.WriteString(" "); za.WriteString(pp[i]);
      i += 1;
    }
    remark.GenComment(za.String());
    FromCalc(varName,-1,npp,&pp); 
  }
}
