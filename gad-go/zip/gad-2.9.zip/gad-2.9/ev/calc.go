// calc.go

package ev

import (
  "fmt"
  "strings"
  "gad/types"
  "gad/rt"
  "gad/rc"
  "gad/w"
  "gad/imp/asm"
  "gad/bug"
  "gad/imp/py"
  "gad/imp/mojo"
g "gad/imp/go"
  "gad/imp/ru"
)


var St []string = make([]string,255);


func AllocResult() string {
  rc.Result = fmt.Sprintf("gad_%d",rc.Zj);
  rc.Zj += 1;
  return rc.Result;
}



func eoi() {
  switch rt.Mode {
  case rt.GO,rt.RUST : w.Wr(";\n");
  case rt.MOJO,rt.PYTHON: w.Wr("\n");
  }
}

func GoOp1(xop string,nt int) int { 
 switch rt.Mode {
 case rt.ASM32: {
   var top = nt - 1;
   var xn1 = St[top];
   asm.Asm32AllocResult(); 
   St[top] = rc.Result;
   top += 1; 
   asm.Asm32Op1(xop,xn1); 
   return top;
 } 
 case rt.ASM: { 
   var top = nt - 1;
   var xn1 = St[top];
   asm.AsmAllocResult(); 
   St[top] = rc.Result;
   top += 1; 
   asm.AsmOp1(xop,xn1); 
   return top; 
  }};
  var top = nt - 1; 
  var xn1 = St[top];
  AllocResult();
  St[top] = rc.Result; top += 1;
  w.To(w.GetIdent()); 
  switch rt.Mode { 
  case rt.GO,rt.MOJO: w.Wr("var "); 
  case rt.RUST: w.Wr("let mut ");  
  }
  w.Wr(rc.Result, " = ", xn1, xop );
  eoi();
  return top;
}

func GoAss(nt int) int {
  fmt.Printf(" goAss (%d) %s = %s\n",nt,St[nt-1],St[nt-2]);
  var /*xn2*/ xn1 = St[nt-1];
  var /*xn1*/ xn2 = St[nt-2]; 
  switch rt.Mode { 
  case rt.ASM32: { asm.Asm32Ass(xn2,xn1); return nt-2; };
  case rt.ASM: { asm.AsmAss(xn2,xn1);  return nt-2; }
  };
  w.To(w.GetIdent());
  w.Wr(xn2, " = ", xn1);
  eoi();
  return nt-2;
}

func GoOp2(xop string,nt int) int {
  switch rt.Mode { 
  case rt.ASM32: {
    var top = nt;
    var /*xn2*/ xn1 = "$0";  if (nt - 1) >= 0 { /*xn2*/ xn1 = St[nt - 1]; top = nt - 1; };
    var /*xn1*/ xn2 = "$0";  if (nt - 2) >= 0 { /*xn1*/ xn2 = St[nt - 2]; top = nt - 2; };
    asm.Asm32AllocResult(); 
    St[top] = rc.Result; top += 1; 
    asm.Asm32Op2(xop,xn2,xn1); 
    return top;
  }
  case rt.ASM: {
    var top = nt;
    var /*xn2*/ xn1 = "$0";  if (nt - 1) >= 0 { /*xn2*/ xn1 = St[nt - 1]; top = nt - 1; };
    var /*xn1*/ xn2 = "$0";  if (nt - 2) >= 0 { /*xn1*/ xn2 = St[nt - 2]; top = nt - 2; };
    asm.AsmAllocResult(); 
    St[top] = rc.Result; top += 1; 
    asm.AsmOp2(xop,xn2,xn1); 
    return top; 
  }};
  var top = nt;
  var /*xn2*/ xn1 = "0";  if (nt - 1) >= 0 { /*xn2*/ xn1 = St[nt - 1]; top = nt -1; }; 
  var /*xn1*/ xn2 = "0";  if (nt - 2) >= 0 { /*xn1*/ xn2 = St[nt - 2]; top = nt -2; };
  AllocResult();
  St[top] = rc.Result; top += 1;
  w.To(w.GetIdent()); 
  switch rt.Mode { 
  case rt.GO,rt.MOJO: w.Wr("var "); case rt.RUST: w.Wr("let mut ");  
  };
  if strings.Contains(" == ; != ; > ; < ; >= ; <= ",xop) {
    rt.NeedBoolOf = true;
    w.Wr(rc.Result); w.Wr(" = ");
    if rt.Mode == rt.GO {
       w.Wr("BoolOf("); w.Wr(xn2); w.Wr(xop); w.Wr(xn1); w.Wr(")");
    };
    if (rt.Mode == rt.RUST) || (rt.Mode ==rt. PYTHON) || (rt.Mode == rt.MOJO) {
       w.Wr("bool_of("); w.Wr(xn2); w.Wr(xop); w.Wr(xn1); w.Wr(")");
    };
  } else {
    w.Wr(rc.Result); w.Wr(" = "); w.Wr(xn2); w.Wr(xop); w.Wr(xn1);
  };   
  eoi();
  return top
}

func genThen() {
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Then();
  case rt.ASM: asm.AsmThen();
  case rt.GO: g.GoThen();
  case rt.RUST: ru.RustThen();
  case rt.MOJO: mojo.MojoThen();
  case rt.PYTHON: py.PythonThen();
  };
}

/*
func genRepeat() {
  rc.Loops[rc.Nev - 1] = true;
  rc.Elses[rc.Nev - 1] = false;
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Repeat();
  case rt.ASM: asm.AsmRepeat();
  case rt.GO:  g.GoRepeat();
  case rt.RUST: ru.RustRepeat();
  case rt.MOJO: mojo.MojoRepeat();
  case rt.PYTHON: py.PyRepeat();
  };
}
*/


func InitRepeat() {
  switch rt.Mode {
  case rt.ASM32,rt.ASM: {
    w.Wr("\n");
    var zp = fmt.Sprintf("ev%d:\n",rc.Evals[ rc.Nev - 1]);
    w.Wr(zp);   
  } 
  case rt.RUST: {
    w.To(w.GetIdent());
    w.Wr("loop {");
    w.To(w.GetIdent() + 2); 
  }
  case rt.GO: {
    w.To(w.GetIdent());
    w.Wr("for {");
    w.To(w.GetIdent() + 2); 
  }
  case rt.PYTHON,rt.MOJO: {
    w.To(w.GetIdent());
    w.Wr("while True:"); 
    w.To(w.GetIdent() + 2); 
  }}
}


/********************************************************/

func GenRepeat() {
  switch rt.Mode {
  case rt.ASM32: asm.Asm32Repeat(); 
  case rt.ASM: asm.AsmRepeat(); 
  case rt.GO: g.GoRepeat(); 
  case rt.RUST: ru.RustRepeat();
  case rt.PYTHON: py.PyRepeat(); 
  case rt.MOJO: mojo.MojoRepeat(); 
  }
}

/********************************************************/

func FromCalc(varName string, iStart int,nv int, p *types.Seq) int {
  bug.DbgTrace("FromCalc");
  var i = iStart; 
  var top = 0;
  //
  i += 1;
  var t,err = types.I(i,nv,p);
  if !err {
    if t == "(" { FromEvil(varName, i, nv, p); return 0; };
    var pole = NotPole(i, nv, p); 
    if pole == "tpt" {
      var pnew,np = Braces(i, nv, p);
      FromEvil(varName,0,np,pnew);
      return 0;
    };
  };
  i -= 1;
  //
  for { i += 1;  
    var t,err = types.I(i,nv,p); if err { break; };
    var is_op = IsOp(t);
    if is_op {
      switch(t) { 
      case "<-","to","->","=": top = GoAss(top); 
      case "inc","++": top = GoOp1(" + 1",top);
      case "<=","le":  top = GoOp2(" <= ", top);
      case "<","lt":   top = GoOp2(" < ",top); 
      case ">=","ge":  top = GoOp2(" >= ",top);
      case ">","gt":   top = GoOp2(" > ", top);
      case "!=","ne":  top = GoOp2(" != ",top);
      case "==","eq":  top = GoOp2(" == ", top);
      case "add","+":  top = GoOp2(" + ",top);
      case "sub", "-": top = GoOp2(" - ",top); 
      case "mul","*":  top = GoOp2(" * ",top);
      case "div","/":  top = GoOp2(" / ",top); 
      case "mod","%":  top = GoOp2(" % ",top);
      };
    } else { St[top] = t; top += 1; };
  }; // for
  if varName != "?" { 
    if rt.Mode == rt.ASM32 { asm.Asm32Ass(varName,St[0]); return 0; };
    if rt.Mode == rt.ASM { asm.AsmAss(varName,St[0]); return 0;  };
    w.To(w.GetIdent());
    w.Wr(varName," = ", St[0] ); 
    eoi();
  };
  bug.DbgTrace(")FromCalc");
  return 0;
}


