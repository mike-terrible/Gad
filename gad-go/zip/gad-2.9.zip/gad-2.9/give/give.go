
// give.go
//
package give

import (
  "strings"
  "gad/words"
  "gad/types"
  "gad/rt"
  "gad/w"
  "gad/ev"
c "gad/cmp"
)

func mojoGiveArray(nv int, p *types.Seq ) {
  var i = 1; i += 1; 
  var t,fuck = types.I(i,nv,p); if fuck { return; };
  w.To(w.GetIdent());
  w.Wr(t, ".__setitem__("); 
  i += 1; t,fuck = types.I(i,nv,p); if fuck { return; }; 
  if !c.Cmp(t,words.WITH)  { return; };
  i += 1; t,fuck = types.I(i,nv,p); if fuck { return; };
  w.Wr(t,",");
  i += 1; if i >= nv { return; };
  i += 1; t,fuck = types.I(i,nv,p); if fuck { return; };
  w.Wr(t);
  if strings.HasPrefix(t,"\"") { w.Wr("\""); }; 
  w.Wr(")\n");
}

func giveArray(nv int, p *types.Seq ) {
  var i = 1; i += 1; 
  var t,fuck = types.I(i,nv,p); if fuck { return; };
  w.To(w.GetIdent()); 
  w.Wr(t);
  i += 1; t,fuck = types.I(i,nv,p); if fuck { return; }; 
  if !c.Cmp(t,words.WITH)  { return; };
  i += 1; t,fuck = types.I(i,nv,p); if fuck { return; };
  i += 1; if i >= nv { return; };
  i += 1; var b,fuckb = types.I(i,nv,p); if fuckb { return; }; 
  w.Wr("[", t, "] =",b);
  if strings.HasPrefix(b,"\"") { w.Wr("\""); };
  switch rt.Mode { 
  case rt.RUST: w.Wr(";\n"); 
  default: w.Wr("\n"); 
  }; 
}


func GenGive(nv int, p *types.Seq )  { 
  var i = 0;
  i += 1; var t,fuck = types.I(i,nv,p); if fuck { return; };
  if c.Cmp(t,words.ARRAY) { 
    if rt.Mode == rt.MOJO { mojoGiveArray(nv,p); return; };
    giveArray(nv,p); return; 
  };
  var varName = t;
  i += 1; // {from}  
  t,fuck = types.I(i,nv,p);  if fuck { return; }; // from | array
  if c.Cmp(t,words.EVAL) { ev.FromCalc(varName, i,nv,p); return; };
  w.To(w.GetIdent());
  switch rt.Mode { case rt.GO,rt.MOJO: w.Wr("var "); case rt.RUST: w.Wr("let mut "); };
  w.Wr(varName," = ");
  if c.Cmp(t,words.ARRAY) { 
    if rt.Mode == rt.MOJO {
      i += 1; var aname,fuck = types.I(i,nv,p); if fuck { return; };
      i += 1; i += 1; t,fuck = types.I(i,nv,p); if fuck { return; };
      w.Wr(aname,".__getitem__(",t,")\n");
      return;
    };
    i += 1; 
    var aname,fuck = types.I(i,nv,p); if fuck { return; };
    i += 1; i += 1; t,fuck = types.I(i,nv,p); if fuck { return; };
    w.Wr(aname,"[",t,"]");
    if rt.Mode == rt.RUST { w.Wr(";"); };
    w.Wr("\n");
    return; 
  } // ARRAY
  //
  i += 1; t,fuck = types.I(i,nv,p); if fuck { return; }; // proc name
  w.Wr(t); var np = 0; // ( 
  for { 
    i += 1; t,fuck = types.I(i,nv,p); if fuck { return; };
    if c.Cmp(t,words.WITH) {
      i += 1; if i>= nv { break; }; 
      var tt,_ = types.I(i,nv,p);
      np += 1; if np >=1 { w.Wr(","); };
      w.Wr(tt); 
      if strings.HasPrefix(tt,"\"") { w.Wr("\""); };
    };    
  };
  if rt.Mode == rt.RUST { w.Wr(");\n"); } else  { w.Wr(")\n"); };
}

