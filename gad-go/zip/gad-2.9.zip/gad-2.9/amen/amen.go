//
// amen.go
//
package amen

import (
  "gad/w"
  "gad/rt"
  "gad/rc"
  "gad/bug"
  "gad/imp/asm"
g "gad/imp/go"
  "gad/imp/ru"
  "gad/imp/mojo"
  "gad/imp/py"
)

func GenInit() {
  w.Wr("\n")
  rt.InArray = false;
}


func GenLoop() {
  bug.DbgTrace("GenLoop");
  switch rt.Mode {
  case rt.ASM32: {
    if rc.Nev > 0 { asm.Asm32Loop(); }; 
    return;
  }
  case rt.ASM: { 
    if rc.Nev > 0 { asm.AsmLoop(); }; 
    return; 
  };
  };
  w.SetIdent(w.GetIdent() - 2); w.To(w.GetIdent());
  switch rt.Mode {
  case rt.RUST: ru.RustLoop();
  case rt.GO:   g.GoLoop();
  case rt.MOJO: mojo.MojoLoop();
  case rt.PYTHON: py.PyLoop();
  };
}

func GenDone() {
  switch rt.Mode { 
  case rt.ASM32: { asm.Asm32Done(); return; } 
  case rt.ASM: { asm.AsmDone(); return; }
  };
  GenLoop(); 
}


func GenAmen() {
  switch rt.Mode {
  case rt.ASM32: { asm.Asm32Amen(); return; }
  case rt.ASM: { asm.AsmAmen(); return;  }
  };
  rt.InProc = false; 
  w.To(w.GetIdent() - 2);
  switch rt.Mode {
  case rt.RUST, rt.GO: { w.Wr("}\n"); }
  case rt.MOJO,rt.PYTHON: { w.Wr("pass\n"); }
  default:
  };
}

