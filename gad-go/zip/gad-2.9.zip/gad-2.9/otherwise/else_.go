
// else_.go
//
package otherwise

import (
  "gad/rt"
  "gad/w"
  "gad/imp/asm"
)

func GenElse()  {
  switch rt.Mode {
  case rt.ASM32: { asm.Asm32Else(); return; }
  case rt.ASM: { asm.AsmElse(); return; }
  };
  w.SetIdent( w.GetIdent() - 2 );
  switch rt.Mode {
  case rt.GO,rt.RUST: { w.To(w.GetIdent()); w.Wr("} else {\n"); } 
  case rt.MOJO,rt.PYTHON: { w.To(w.GetIdent()); w.Wr("else:\n");  }
  };
  w.SetIdent( w.GetIdent() + 2 );
}

