
// gogad.go main
//
package main

import (
  "os"
  "fmt"
  "gad/version"
  "gad/pa"
)

func main() {
  fmt.Println("gad compiler ", version.Ver);
  var z = os.Args;
  var n = len(z)
  var fn = ""
  var  mode = "-go"
  if n > 1 { fn = os.Args[1]; }
  if n > 2 { mode = os.Args[2]; }
  if n > 1 { pa.Parser(fn,mode); return; }
  fmt.Println("USAGE: gad fname [-go | -rust | -mojo | -python | -asm | -asm32 ]")
}

